import os
import uuid
from dotenv import load_dotenv
from typing import TypedDict, Annotated
from rich.console import Console

from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage, BaseMessage
from langchain_core.runnables import RunnableConfig

from langchain.embeddings import OpenAIEmbeddings

from langgraph.graph import StateGraph
from langgraph.graph.message import add_messages
from langgraph.checkpoint.mongodb import MongoDBSaver
from langgraph.store.mongodb import MongoDBStore
from langgraph.store.base import BaseStore

# --- Setup ---
load_dotenv()
console = Console()

class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]

def call_model(state: AgentState, config: RunnableConfig, *, store: BaseStore):
    user_id = config["configurable"]["user_id"]
    namespace = ("memories", user_id)

    query = str(state["messages"][-1].content)
    memories = store.search(namespace, query=query)
    info = "\n".join([d.value["data"] for d in memories])
    system_msg = f"You are a helpful assistant talking to the user. Retrieved info: {info}"

    if "remember" in query.lower():
        memory = "User name is Bob"
        store.put(namespace, str(uuid.uuid4()), {"data": memory})

    response = model.invoke([{"role": "system", "content": system_msg}] + state["messages"])
    return {"messages": [response]}

# --- Main Execution ---
if __name__ == "__main__":
    model = AzureChatOpenAI(
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        api_version="2024-02-15-preview",
        model="gpt-4o",
        temperature=0.7,
    )

    # ✅ Initialize embeddings
    embeddings = OpenAIEmbeddings(api_key=os.getenv("AZURE_OPENAI_API_KEY"))

    # MongoDB URI
    mongo_uri = os.getenv("MONGODB_URI", "mongodb://localhost:27017")

    with (
        MongoDBStore.from_conn_string(mongo_uri, embeddings=embeddings) as store,
        MongoDBSaver.from_conn_string(mongo_uri) as memory
    ):
        builder = StateGraph(AgentState)
        builder.add_node("agent", call_model)
        builder.set_entry_point("agent")
        builder.set_finish_point("agent")

        graph = builder.compile(checkpointer=memory, store=store)

        console.print("[bold green]MongoDB Agent with semantic memory is ready! Type 'quit' to exit.[/bold green]")
        thread_id = "mongo-semantic-thread-001"
        user_id = "vishwanath-embeddings-user"

        while True:
            user_input = console.input("[bold blue]You: [/bold blue]").strip()
            if user_input.lower() == "quit":
                console.print("[bold red]Goodbye![/bold red]")
                break

            input_messages = [HumanMessage(content=user_input)]
            config = {
                "configurable": {
                    "thread_id": thread_id,
                    "user_id": user_id,
                }
            }

            for chunk in graph.stream({"messages": input_messages}, config=config):
                if "agent" in chunk:
                    response_message = chunk["agent"]["messages"][-1]
                    console.print(f"[bold green]Agent: [/bold green]{response_message.content}")

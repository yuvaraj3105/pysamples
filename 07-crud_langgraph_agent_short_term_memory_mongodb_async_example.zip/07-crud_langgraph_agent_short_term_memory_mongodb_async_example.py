"""
07-langgraph_agent_short_term_memory_mongodb_async_example.py
-----------------------------------------------------------

A simple async chatbot agent using Azure OpenAI (via LangChain) and LangGraph with MongoDB for persistent, resumable short-term memory.

Features:
- Asynchronous chat agent using Azure OpenAI (gpt-4o or other model)
- Conversation state (messages) is checkpointed in MongoDB using LangGraph's AsyncMongoDBSaver
- Each session is identified by a unique thread ID (passed via --thread-id)
- You can resume a session by specifying the same thread ID
- All conversation history is stored and loaded from MongoDB
- Easily extensible for multi-step or multi-node agent workflows
- **Memory management CLI:** Add, list, get, and delete user memories in a separate collection

Usage:
    python 07-crud_langgraph_agent_short_term_memory_mongodb_async_example.py --thread-id <your-session-id>

Example:
    python 07-crud_langgraph_agent_short_term_memory_mongodb_async_example.py --thread-id alice-session
    python 07-crud_langgraph_agent_short_term_memory_mongodb_async_example.py --thread-id bob-session
    python 07-crud_langgraph_agent_short_term_memory_mongodb_async_example.py --thread-id alice-session --add-memory "I love pizza" "food"
    python 07-crud_langgraph_agent_short_term_memory_mongodb_async_example.py --thread-id alice-session --list-memories

Environment variables required (can be set in .env):
- AZURE_OPENAI_API_KEY
- AZURE_OPENAI_ENDPOINT
- AZURE_OPENAI_DEPLOYMENT_NAME
- MONGODB_URI (default: mongodb://localhost:27017)

Type 'quit' in the chat to exit the session.
"""

import os
import sys
import asyncio
from dotenv import load_dotenv
from typing import TypedDict, Annotated
from rich.console import Console
import argparse
from motor.motor_asyncio import AsyncIOMotorClient
from bson.objectid import ObjectId

from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage, BaseMessage

from langgraph.graph import StateGraph
from langgraph.graph.message import add_messages
from langgraph.checkpoint.mongodb.aio import AsyncMongoDBSaver  # ✅ Asynchronous MongoDB checkpointer

# --- Setup ---
load_dotenv()
console = Console()

# --- CLI argument parsing for thread id and memory management ---
parser = argparse.ArgumentParser(description="LangGraph MongoDB Chatbot with Memory CRUD")
parser.add_argument('--thread-id', type=str, default='mongo-azure-user-789', help='Session thread ID for the chat')
parser.add_argument('--add-memory', nargs=2, metavar=('CONTENT', 'CONTEXT'), help='Add a new memory with content and context')
parser.add_argument('--list-memories', action='store_true', help='List all memories for the user')
parser.add_argument('--get-memory', type=str, help='Get a memory by its ID')
parser.add_argument('--delete-memory', type=str, help='Delete a memory by its ID')
args = parser.parse_args()

# Define the state structure for LangGraph
class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]

# --- Memory management helpers ---
async def get_memories(memories_collection, user_id):
    cursor = memories_collection.find({"user_id": user_id})
    return [doc async for doc in cursor]

async def add_memory(memories_collection, user_id, content, context):
    doc = {"user_id": user_id, "content": content, "context": context}
    result = await memories_collection.insert_one(doc)
    return str(result.inserted_id)

async def get_memory(memories_collection, memory_id):
    return await memories_collection.find_one({"_id": ObjectId(memory_id)})

async def delete_memory(memories_collection, memory_id):
    result = await memories_collection.delete_one({"_id": ObjectId(memory_id)})
    return result.deleted_count > 0

# Async model invocation node
async def call_model(state: AgentState):
    response = await model.ainvoke(state["messages"])
    return {"messages": [response]}

# --- Async Main Execution ---
async def main():
    global model  # Required since call_model references it
    model = AzureChatOpenAI(
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        api_version="2024-02-15-preview",
        model="gpt-4o",
        temperature=0.7,
    )

    mongo_uri = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
    user_id = args.thread_id  # Use thread_id as user_id for simplicity

    # Setup MongoDB client for memories
    mongo_client = AsyncIOMotorClient(mongo_uri)
    db_name = os.getenv("MONGODB_DB", "test")
    db = mongo_client[db_name]
    memories_collection = db.user_memories

    # --- Handle memory management CLI commands ---
    if args.add_memory:
        content, context = args.add_memory
        mem_id = await add_memory(memories_collection, user_id, content, context)
        console.print(f"Added memory with ID: {mem_id}")
        return
    if args.list_memories:
        memories = await get_memories(memories_collection, user_id)
        if not memories:
            console.print("No memories found.")
        else:
            for m in memories:
                console.print(f"[ID: {m['_id']}] {m['content']} (context: {m['context']})")
        return
    if args.get_memory:
        mem = await get_memory(memories_collection, args.get_memory)
        if mem:
            console.print(f"[ID: {mem['_id']}] {mem['content']} (context: {mem['context']})")
        else:
            console.print("No memory found with that ID.")
        return
    if args.delete_memory:
        deleted = await delete_memory(memories_collection, args.delete_memory)
        if deleted:
            console.print(f"Deleted memory with ID: {args.delete_memory}")
        else:
            console.print("No memory found with that ID.")
        return

    # --- Chatbot session as before ---
    async with AsyncMongoDBSaver.from_conn_string(mongo_uri) as memory:
        builder = StateGraph(AgentState)
        builder.add_node("agent", call_model)
        builder.set_entry_point("agent")
        builder.set_finish_point("agent")

        graph = builder.compile(checkpointer=memory)

        console.print("[bold green]Async Agent is ready! Type 'quit' to exit.[/bold green]")
        thread_id = args.thread_id

        while True:
            user_input = await asyncio.to_thread(console.input, "[bold blue]You: [/bold blue]")
            user_input = user_input.strip()

            if user_input.lower() == "quit":
                console.print("[bold red]Goodbye![/bold red]")
                break

            input_messages = [HumanMessage(content=user_input)]
            config = {"configurable": {"thread_id": thread_id}}

            async for chunk in graph.astream({"messages": input_messages}, config=config):
                if "agent" in chunk:
                    response_message = chunk["agent"]["messages"][-1]
                    console.print(f"[bold green]Agent: [/bold green]{response_message.content}")

# Windows compatibility fix
if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(main())

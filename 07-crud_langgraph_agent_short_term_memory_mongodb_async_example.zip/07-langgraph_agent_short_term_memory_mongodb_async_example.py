"""
07-langgraph_agent_short_term_memory_mongodb_async_example.py
-----------------------------------------------------------

A simple async chatbot agent using Azure OpenAI (via LangChain) and LangGraph with MongoDB for persistent, resumable short-term memory.

Features:
- Asynchronous chat agent using Azure OpenAI (gpt-4o or other model)
- Conversation state (messages) is checkpointed in MongoDB using LangGraph's AsyncMongoDBSaver
- Each session is identified by a unique thread ID (passed via --thread-id)
- You can resume a session by specifying the same thread ID
- All conversation history is stored and loaded from MongoDB
- Easily extensible for multi-step or multi-node agent workflows

Usage:
    python 07-langgraph_agent_short_term_memory_mongodb_async_example.py --thread-id <your-session-id>

Example:
    python 07-langgraph_agent_short_term_memory_mongodb_async_example.py --thread-id alice-session
    python 07-langgraph_agent_short_term_memory_mongodb_async_example.py --thread-id bob-session

Environment variables required (can be set in .env):
- AZURE_OPENAI_API_KEY
- AZURE_OPENAI_ENDPOINT
- AZURE_OPENAI_DEPLOYMENT_NAME
- MONGODB_URI (default: mongodb://localhost:27017)

Type 'quit' in the chat to exit the session.
"""

import os
import sys
import asyncio
from dotenv import load_dotenv
from typing import TypedDict, Annotated
from rich.console import Console
import argparse

from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage, BaseMessage

from langgraph.graph import StateGraph
from langgraph.graph.message import add_messages
from langgraph.checkpoint.mongodb.aio import AsyncMongoDBSaver  # ✅ Asynchronous MongoDB checkpointer

# --- Setup ---
load_dotenv()
console = Console()

# --- CLI argument parsing for thread id ---
parser = argparse.ArgumentParser(description="LangGraph MongoDB Chatbot")
parser.add_argument('--thread-id', type=str, default='mongo-azure-user-789', help='Session thread ID for the chat')
args = parser.parse_args()

# Define the state structure for LangGraph
class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]

# Async model invocation node
async def call_model(state: AgentState):
    response = await model.ainvoke(state["messages"])
    return {"messages": [response]}

# --- Async Main Execution ---
async def main():
    global model  # Required since call_model references it
    model = AzureChatOpenAI(
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        api_version="2024-02-15-preview",
        model="gpt-4o",
        temperature=0.7,
    )

    # MongoDB URI
    mongo_uri = os.getenv("MONGODB_URI", "mongodb://localhost:27017")

    # ✅ Use async context manager for MongoDB saver
    async with AsyncMongoDBSaver.from_conn_string(mongo_uri) as memory:
        builder = StateGraph(AgentState)
        builder.add_node("agent", call_model)
        builder.set_entry_point("agent")
        builder.set_finish_point("agent")

        graph = builder.compile(checkpointer=memory)

        console.print("[bold green]Async Agent is ready! Type 'quit' to exit.[/bold green]")
        thread_id = args.thread_id

        while True:
            user_input = await asyncio.to_thread(console.input, "[bold blue]You: [/bold blue]")
            user_input = user_input.strip()

            if user_input.lower() == "quit":
                console.print("[bold red]Goodbye![/bold red]")
                break

            input_messages = [HumanMessage(content=user_input)]
            config = {"configurable": {"thread_id": thread_id}}

            async for chunk in graph.astream({"messages": input_messages}, config=config):
                if "agent" in chunk:
                    response_message = chunk["agent"]["messages"][-1]
                    console.print(f"[bold green]Agent: [/bold green]{response_message.content}")

# Windows compatibility fix
if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(main())

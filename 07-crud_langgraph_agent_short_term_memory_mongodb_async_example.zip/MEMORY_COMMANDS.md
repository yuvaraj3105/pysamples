# Memory Management Commands (Short Term Memory Agent)

This document provides a quick reference for all memory management commands available in the short_term_memory_agent, for both CLI and chat.

---

## CLI Commands

### List all memories
```bash
python -m short_term_memory_agent --list-memories
```

### Get a memory by ID
```bash
python -m short_term_memory_agent --get-memory <id>
```

### Delete a memory by ID
```bash
python -m short_term_memory_agent --delete-memory <id>
```

### Add a new memory
```bash
python -m short_term_memory_agent --add-memory "content here" "context here"
```

### Add default memories
```bash
python -m short_term_memory_agent --add-default-memories
```

---

## Chat Commands

Type these commands while running interactively:

### List all memories
```
/list_memories
```

### Get a memory by ID
```
/get_memory <id>
```

### Delete a memory by ID
```
/delete_memory <id>
```

### Add a new memory
```
/add_memory <content> <context>
```

### Add default memories
```
/add_default_memories
```

---

## Notes
- Use `/list_memories` to find memory IDs for use with other commands.
- All commands use the default user_id 'local-user'.
- For more details, see the README. 
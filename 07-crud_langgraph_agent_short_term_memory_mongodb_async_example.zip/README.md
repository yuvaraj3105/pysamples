# Short Term Memory Agent

A simple conversational agent with short-term memory, using MongoDB for storage. Supports both interactive chat and CLI memory management commands.

---

## Installation

1. **Clone the repository** and enter the project directory:
   ```bash
   cd short_term_memory_linux
   ```
2. **Create and activate a virtual environment (optional but recommended):**
   ```bash
   python3 -m venv my-venv
   source my-venv/bin/activate
   ```
3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
4. **Set up your `.env` file** with your MongoDB and Azure OpenAI credentials:
   ```env
   MONGODB_URI=mongodb://localhost:27017
   AZURE_OPENAI_API_KEY=your-key
   AZURE_OPENAI_ENDPOINT=your-endpoint
   AZURE_OPENAI_DEPLOYMENT_NAME=your-deployment
   ```
5. **Start MongoDB** (if not already running):
   ```bash
   mongod --dbpath /data/db
   ```

---

## Running the Agent

Start the agent in interactive chat mode:
```bash
python -m short_term_memory_agent
```

You will see:
```
Async Agent is ready! Type 'quit' to exit.
Session thread_id: <unique-id>
You:
```

---

## Memory Management via CLI

### List all memories
```bash
python -m short_term_memory_agent --list-memories
```

### Get a memory by ID
```bash
python -m short_term_memory_agent --get-memory <id>
```

### Delete a memory by ID
```bash
python -m short_term_memory_agent --delete-memory <id>
```

### Add a new memory
```bash
python -m short_term_memory_agent --add-memory "content here" "context here"
```

### Add default memories
```bash
python -m short_term_memory_agent --add-default-memories
```

---

## Memory Management via Chat Commands

While running interactively, type:

### List all memories
```
/list_memories
```

### Get a memory by ID
```
/get_memory <id>
```

### Delete a memory by ID
```
/delete_memory <id>
```

### Add a new memory
```
/add_memory <content> <context>
```

### Add default memories
```
/add_default_memories
```

---

## Example Session

```
$ python -m short_term_memory_agent
Async Agent is ready! Type 'quit' to exit.
Session thread_id: 123e4567-e89b-12d3-a456-426614174000
You: /add_memory "Likes pizza" "Food preference"
Added memory with ID: 1a2b3c4d
You: /list_memories
[ID: 1a2b3c4d] {'content': 'Likes pizza', 'context': 'Food preference'}
You: /delete_memory 1a2b3c4d
Deleted memory with ID: 1a2b3c4d
You: quit
Goodbye!
```

---

## Notes
- All memory commands work with the default user_id 'local-user'.
- Memory IDs can be found using the list command.
- For advanced usage, see `short_term_memory_agent/memory_utils.py`. 
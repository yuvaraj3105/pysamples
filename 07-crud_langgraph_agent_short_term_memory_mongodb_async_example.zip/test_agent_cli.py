import subprocess
import uuid
import time

def run_cmd(cmd):
    print(f"\n$ {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print("STDERR:", result.stderr)
    return result

# Generate a unique thread id for this test run
thread_id = f"test-session-{uuid.uuid4()}"

# Start a chat session (simulate by running and quitting)
run_cmd(f"echo 'quit' | python -m short_term_memory_agent --thread-id {thread_id}")

# Give MongoDB a moment to flush
time.sleep(1)

# List all threads
run_cmd("python -m short_term_memory_agent --list-threads")

# List messages for the session
run_cmd(f"python -m short_term_memory_agent --list-memories --thread-id {thread_id}")

# Add a memory
run_cmd("python -m short_term_memory_agent --add-memory 'I love pizza' 'food'")

# List all memories (vector store)
run_cmd("python -m short_term_memory_agent --list-memories")

# Add default memories
run_cmd("python -m short_term_memory_agent --add-default-memories")

# List all memories again to see the new ones
run_cmd("python -m short_term_memory_agent --list-memories") 
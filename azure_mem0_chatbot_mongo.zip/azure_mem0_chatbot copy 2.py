"""
azure_mem0_chatbot.py
---------------------

A simple multi-user chatbot using Azure OpenAI (via LangChain) and Mem0 for advanced memory management.

Features:
- Multi-user support: Pass --user-name <username> via CLI to start a session for a specific user.
- Chatbot with persistent memory: Stores all user and assistant messages in Mem0.
- Advanced Memory Management Commands (type in chat):
    /memories                - List all memories for the current user.
    /search <keyword>        - Search memories for the current user by keyword.
    /update <id> <content>   - Update a memory by its ID (will prompt for new context).
    /delete <id>             - Delete a memory by its ID.
    exit                     - Quit the chatbot.

Usage:
    python azure_mem0_chatbot.py --user-name alice

Example session:
    You: Hello!
    Bot: Hi there! How can I help you today?
    You: /memories
    (Lists all memories for user 'alice')
    You: /search pizza
    (Lists all memories containing 'pizza')
    You: /update 12345abc New favorite food is sushi
    Enter new context for this memory: Updated after recent conversation
    (Updates memory with ID '12345abc')
    You: /delete 12345abc
    (Deletes memory with ID '12345abc')
    You: exit
    Goodbye!

Environment variables required (can be set in .env):
- AZURE_OPENAI_API_KEY
- AZURE_OPENAI_ENDPOINT
- AZURE_OPENAI_DEPLOYMENT_NAME
- AZURE_OPENAI_API_VERSION
- AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME

"""
import os
import argparse
from mem0 import Memory
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from dotenv import load_dotenv

# Load environment variables from .env if present
load_dotenv()

# Set your environment variables
os.environ["AZURE_OPENAI_API_KEY"] = os.getenv("AZURE_OPENAI_API_KEY", "your-azure-openai-api-key")
os.environ["AZURE_OPENAI_ENDPOINT"] = os.getenv("AZURE_OPENAI_ENDPOINT", "your-azure-endpoint")
os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "your-deployment-name")
os.environ["AZURE_OPENAI_API_VERSION"] = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")

# You'll need an embedding deployment name as well
EMBEDDING_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME", "your-embedding-deployment-name")

# Initialize Azure OpenAI LLM through LangChain
azure_llm = AzureChatOpenAI(
    azure_deployment=os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"],
    api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    temperature=0.1,
    max_tokens=2000
)

# Initialize Azure OpenAI Embeddings through LangChain
azure_embeddings = AzureOpenAIEmbeddings(
    azure_deployment=EMBEDDING_DEPLOYMENT_NAME,  # Your embedding deployment name
    api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
)

# Configure Mem0 to use LangChain providers
config = {
    "llm": {
        "provider": "langchain",
        "config": {
            "model": azure_llm
        }
    },
    "embedder": {
        "provider": "langchain",
        "config": {
            "model": azure_embeddings
        }
    }
}

# Initialize Mem0 with LangChain Azure OpenAI
memory = Memory.from_config(config)

# Add CLI argument parsing for username
parser = argparse.ArgumentParser(description="Azure OpenAI + Mem0 Chatbot")
parser.add_argument('--user-name', type=str, default='default_user', help='Username for the chat session')
args = parser.parse_args()
user_id = args.user_name

print("Simple Azure OpenAI + Mem0 Chatbot (type 'exit' to quit)")
history = []

while True:
    user_input = input("You: ").strip()
    if user_input.lower() == "exit":
        print("Goodbye!")
        break
    if user_input.lower() == "/memories":
        # Retrieve all memories for the user
        result = memory.get_all(user_id=user_id)
        memories = result["results"] if isinstance(result, dict) and "results" in result else result
        if not memories:
            print("No memories found for this user.")
        else:
            print(f"Found {len(memories)} memories:")
            for i, mem in enumerate(memories, 1):
                print(f"{i}. ID: {mem.get('id', 'N/A')} | Content: {mem.get('memory', 'N/A')} | Context: {mem.get('metadata', {}).get('context', 'N/A') if mem.get('metadata') else 'N/A'}")
        continue
    if user_input.lower().startswith("/search "):
        keyword = user_input[8:].strip()
        if not keyword:
            print("Usage: /search <keyword>")
            continue
        result = memory.search(keyword, user_id=user_id)
        if not result:
            print("No matching memories found.")
        else:
            print(f"Found {len(result)} matching memories:")
            for i, mem in enumerate(result, 1):
                print(f"{i}. ID: {mem.get('id', 'N/A')} | Content: {mem.get('memory', 'N/A')} | Context: {mem.get('metadata', {}).get('context', 'N/A') if mem.get('metadata') else 'N/A'}")
        continue
    if user_input.lower().startswith("/update "):
        parts = user_input.split(maxsplit=2)
        if len(parts) < 3:
            print("Usage: /update <memory_id> <new_content>")
            continue
        memory_id, new_content = parts[1], parts[2]
        new_context = input("Enter new context for this memory: ").strip()
        update_data = {"data": new_content, "context": new_context}
        try:
            memory.update(memory_id, update_data)
            print(f"Memory {memory_id} updated.")
        except Exception as e:
            print(f"Error updating memory: {e}")
        continue
    if user_input.lower().startswith("/delete "):
        parts = user_input.split(maxsplit=1)
        if len(parts) < 2:
            print("Usage: /delete <memory_id>")
            continue
        memory_id = parts[1]
        try:
            memory.delete(memory_id)
            print(f"Memory {memory_id} deleted.")
        except Exception as e:
            print(f"Error deleting memory: {e}")
        continue
    # Add the user message to the history
    history.append({"role": "user", "content": user_input})
    # Add the message to memory
    memory.add([{"role": "user", "content": user_input}], user_id=user_id)
    # Get the LLM response using the actual LangChain LLM object
    response_msg = azure_llm.invoke(history)
    # Extract the content from the AIMessage object if needed
    response = response_msg.content if hasattr(response_msg, 'content') else str(response_msg)
    # Add the assistant's response to the history
    history.append({"role": "assistant", "content": response})
    print("Bot:", response)
"""
azure_mem0_chatbot.py
---------------------

A simple multi-user chatbot using Azure OpenAI (via LangChain) and Mem0 for advanced memory management.

Features:
- Multi-user support: Pass --user-name <username> via CLI to start a session for a specific user.
- Chatbot with persistent memory: Stores all user and assistant messages in Mem0.
- **Persistent chat history across sessions using PostgreSQL**: Chat history is loaded from the database on startup, saved after each message, and cleared from the database on /clear_history. Each user's chat history is preserved between sessions.
- **Automatic database and table creation**: If the PostgreSQL database (mem0_database) or the chat_history table do not exist, the script will create them automatically at startup.
- **/memories always reflects full chat history**: After loading chat history from the database, the script re-populates Mem0 with all past messages for the user, so /memories always shows the user's complete chat history across sessions.
- **Semantic search with pgvector**: Each message is stored with an embedding (VECTOR(1536)), and you can use /semantic_search <query> to find the most semantically similar messages in your chat history using pgvector's cosine distance.
- Advanced Memory Management Commands (type in chat):
    /memories                - List all memories for the current user (reflects full chat history).
    /search <keyword>        - Search memories for the current user by keyword.
    /semantic_search <query> - Find semantically similar messages using pgvector.
    /update <id> <content>   - Update a memory by its ID (will prompt for new context).
    /delete <id>             - Delete a memory by its ID.
    /history                 - Show the current session's chat history (user and assistant messages).
    /clear_history           - Clear the current session's chat history (and also clears from the database; optionally, also clear all memories for the user).
    exit                     - Quit the chatbot.

Usage:
    python azure_mem0_chatbot.py --user-name alice

Example session:
    You: Hello!
    Bot: Hi there! How can I help you today?
    You: /memories
    (Lists all memories for user 'alice', including all past chat history)
    You: /search pizza
    (Lists all memories containing 'pizza')
    You: /semantic_search bmw suv
    (Lists the most semantically similar messages to 'bmw suv' using pgvector)
    You: /update 12345abc New favorite food is sushi
    Enter new context for this memory: Updated after recent conversation
    (Updates memory with ID '12345abc')
    You: /delete 12345abc
    (Deletes memory with ID '12345abc')
    You: /history
    (Shows the current session's chat history)
    You: /clear_history
    (Clears the session's chat history and database history, and optionally all memories)
    You: exit
    Goodbye!

Environment variables required (can be set in .env):
- AZURE_OPENAI_API_KEY
- AZURE_OPENAI_ENDPOINT
- AZURE_OPENAI_DEPLOYMENT_NAME
- AZURE_OPENAI_API_VERSION
- AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME
- PSQL_USERNAME
- PSQL_PASSWORD
- PSQL_HOST
- PSQL_PORT
- PSQL_DATABASE (default: mem0_database)
- PSQL_SSLMODE

PostgreSQL setup:
- The script will automatically create the database 'mem0_database' and the table 'chat_history' if they do not exist.
- Table schema: chat_history (id SERIAL PRIMARY KEY, user_id TEXT, role TEXT, content TEXT, embedding VECTOR(1536), timestamp TIMESTAMP)
- The script enables the pgvector extension automatically for semantic search.

"""
import os
import argparse
from mem0 import Memory
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from dotenv import load_dotenv
import psycopg2
from psycopg2 import sql
import sys
import numpy as np

# Load environment variables from .env if present
load_dotenv()

# Set your environment variables
os.environ["AZURE_OPENAI_API_KEY"] = os.getenv("AZURE_OPENAI_API_KEY", "your-azure-openai-api-key")
os.environ["AZURE_OPENAI_ENDPOINT"] = os.getenv("AZURE_OPENAI_ENDPOINT", "your-azure-endpoint")
os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "your-deployment-name")
os.environ["AZURE_OPENAI_API_VERSION"] = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")

# You'll need an embedding deployment name as well
EMBEDDING_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME", "your-embedding-deployment-name")

# PostgreSQL connection parameters (use env vars or defaults)
PSQL_USERNAME = os.getenv("PSQL_USERNAME", "postgres")
PSQL_PASSWORD = os.getenv("PSQL_PASSWORD", "admin123")
PSQL_HOST = os.getenv("PSQL_HOST", "localhost")
PSQL_PORT = int(os.getenv("PSQL_PORT", 5432))
PSQL_DATABASE = os.getenv("PSQL_DATABASE", "mem0_database")
PSQL_SSLMODE = os.getenv("PSQL_SSLMODE", "disable")

# Helper functions (move all above their first use)
def get_db_connection():
    return psycopg2.connect(
        dbname=PSQL_DATABASE,
        user=PSQL_USERNAME,
        password=PSQL_PASSWORD,
        host=PSQL_HOST,
        port=PSQL_PORT,
        sslmode=PSQL_SSLMODE
    )

def create_table_if_not_exists():
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            # Enable pgvector extension if not already enabled
            cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
            cur.execute('''
                CREATE TABLE IF NOT EXISTS chat_history (
                    id SERIAL PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    embedding VECTOR(1536),  -- 1536 for OpenAI/Azure embeddings
                    timestamp TIMESTAMP DEFAULT NOW()
                )
            ''')
        conn.commit()

def load_history(user_id):
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT role, content, timestamp FROM chat_history WHERE user_id=%s ORDER BY timestamp ASC", (user_id,))
            return [{"role": row[0], "content": row[1], "timestamp": row[2]} for row in cur.fetchall()]

def save_message(user_id, role, content, timestamp=None):
    import datetime
    if timestamp is None:
        timestamp = datetime.datetime.now()
    embedding = get_embedding(content)
    # Convert embedding to Python list if it's a numpy array
    if isinstance(embedding, np.ndarray):
        embedding = embedding.tolist()
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO chat_history (user_id, role, content, embedding, timestamp) VALUES (%s, %s, %s, %s, %s)",
                (user_id, role, content, embedding, timestamp)
            )
        conn.commit()

def clear_history_db(user_id):
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM chat_history WHERE user_id=%s", (user_id,))
        conn.commit()

def get_embedding(text):
    return azure_embeddings.embed_query(text)

def semantic_search(user_id, query, top_k=5):
    embedding = get_embedding(query)
    if isinstance(embedding, np.ndarray):
        embedding = embedding.tolist()
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT content, role, timestamp, embedding <#> %s::vector AS cosine_distance
                FROM chat_history
                WHERE user_id = %s
                ORDER BY embedding <#> %s::vector
                LIMIT %s
                """,
                (embedding, user_id, embedding, top_k)
            )
            return cur.fetchall()

# Ensure table exists at startup
# create_table_if_not_exists()

# Initialize Azure OpenAI LLM through LangChain
azure_llm = AzureChatOpenAI(
    azure_deployment=os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"],
    api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    temperature=0.1,
    max_tokens=2000
)

# Initialize Azure OpenAI Embeddings through LangChain
azure_embeddings = AzureOpenAIEmbeddings(
    azure_deployment=EMBEDDING_DEPLOYMENT_NAME,  # Your embedding deployment name
    api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
)

# Configure Mem0 to use LangChain providers
config = {
    "llm": {
        "provider": "langchain",
        "config": {
            "model": azure_llm
        }
    },
    "embedder": {
        "provider": "langchain",
        "config": {
            "model": azure_embeddings
        }
    }
}

# Initialize Mem0 with LangChain Azure OpenAI
memory = Memory.from_config(config)

# Utility: Re-embed all messages with NULL embedding for the current user

def reembed_missing_embeddings(user_id):
    print(f"[INFO] Checking for messages without embeddings for user '{user_id}'...")
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT id, content FROM chat_history WHERE user_id=%s AND embedding IS NULL", (user_id,))
            rows = cur.fetchall()
            if not rows:
                print("All messages have embeddings.")
                return
            print(f"Found {len(rows)} messages without embeddings. Re-embedding now...")
            for msg_id, content in rows:
                embedding = get_embedding(content)
                if isinstance(embedding, np.ndarray):
                    embedding = embedding.tolist()
                cur.execute("UPDATE chat_history SET embedding=%s WHERE id=%s", (embedding, msg_id))
            conn.commit()
            print(f"Re-embedded {len(rows)} messages for user '{user_id}'.")

# Utility: Re-embed all messages with NULL embedding for all users

def reembed_missing_embeddings_all_users():
    print(f"[INFO] Checking for messages without embeddings for all users...")
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT DISTINCT user_id FROM chat_history")
            user_ids = [row[0] for row in cur.fetchall()]
    for user_id in user_ids:
        reembed_missing_embeddings(user_id)

# --- CLI argument parsing (fix for utility commands) ---
parser = argparse.ArgumentParser(description="Azure OpenAI + Mem0 Chatbot")
parser.add_argument('--user-name', type=str, default='default_user', help='Username for the chat session')
parser.add_argument('--reembed-missing', action='store_true', help='Re-embed missing embeddings for a user')
parser.add_argument('--reembed-missing-all', action='store_true', help='Re-embed missing embeddings for all users')
args, unknown = parser.parse_known_args()
user_id = args.user_name

# Add CLI command to re-embed missing embeddings for all users
if args.reembed_missing_all:
    reembed_missing_embeddings_all_users()
    sys.exit(0)
# Add CLI command to re-embed missing embeddings for a user
if args.reembed_missing:
    reembed_missing_embeddings(user_id)
    sys.exit(0)

# --- Move the check functions here so they are defined before use ---
def check_azure_openai():
    try:
        # Try a simple call to the Azure OpenAI LLM
        _ = azure_llm.invoke([{"role": "system", "content": "ping"}])
        print("Azure OpenAI API: OK")
        return True
    except Exception as e:
        print(f"Azure OpenAI API check failed: {e}")
        return False

def check_db_connection():
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
        print("PostgreSQL connection: OK")
        return True
    except psycopg2.OperationalError as e:
        # Check if error is due to missing database
        if f'database "{PSQL_DATABASE}" does not exist' in str(e):
            print(f"Database '{PSQL_DATABASE}' does not exist. Creating...")
            try:
                # Connect to default 'postgres' database
                conn = psycopg2.connect(
                    dbname="postgres",
                    user=PSQL_USERNAME,
                    password=PSQL_PASSWORD,
                    host=PSQL_HOST,
                    port=PSQL_PORT,
                    sslmode=PSQL_SSLMODE
                )
                conn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
                with conn.cursor() as cur:
                    cur.execute(f"CREATE DATABASE {PSQL_DATABASE}")
                conn.close()
                print(f"Database '{PSQL_DATABASE}' created.")
                # Try connecting again
                with get_db_connection() as conn2:
                    with conn2.cursor() as cur2:
                        cur2.execute("SELECT 1")
                print("PostgreSQL connection: OK")
                return True
            except Exception as ce:
                print(f"Failed to create database '{PSQL_DATABASE}': {ce}")
                return False
        else:
            print(f"PostgreSQL connection failed: {e}")
            return False
    except Exception as e:
        print(f"PostgreSQL connection failed: {e}")
        return False

def check_table_exists():
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_name = 'chat_history'
                    )
                """)
                exists = cur.fetchone()[0]
        if exists:
            print("chat_history table: OK")
            return True
        else:
            print("chat_history table does not exist. Creating...")
            create_table_if_not_exists()
            print("chat_history table created.")
            return True
    except Exception as e:
        print(f"chat_history table check failed: {e}")
        return False
# --- End move ---

# Run all checks before starting chatbot
if not check_azure_openai() or not check_db_connection() or not check_table_exists():
    print("Startup checks failed. Exiting.")
    sys.exit(1)

# Now load persistent history for this user
history = load_history(user_id)

# Re-populate Mem0 with all chat history for this user
for msg in history:
    memory.add([{"role": msg["role"], "content": msg["content"]}], user_id=user_id)

print("Simple Azure OpenAI + Mem0 Chatbot (type 'exit' to quit)")

while True:
    user_input = input("You: ").strip()
    if user_input.lower() == "exit":
        print("Goodbye!")
        break
    if user_input.lower() == "/memories":
        # Retrieve all memories for the user
        result = memory.get_all(user_id=user_id)
        memories = result["results"] if isinstance(result, dict) and "results" in result else result
        if not memories:
            print("No memories found for this user.")
        else:
            print(f"Found {len(memories)} memories:")
            for i, mem in enumerate(memories, 1):
                print(f"{i}. ID: {mem.get('id', 'N/A')} | Content: {mem.get('memory', 'N/A')} | Context: {mem.get('metadata', {}).get('context', 'N/A') if mem.get('metadata') else 'N/A'}")
        continue
    if user_input.lower().startswith("/search "):
        keyword = user_input[8:].strip()
        if not keyword:
            print("Usage: /search <keyword>")
            continue
        result = memory.search(keyword, user_id=user_id)
        # If result is a dict with 'results', extract the list
        if isinstance(result, dict) and "results" in result:
            result_list = result["results"]
        else:
            result_list = result
        if not result_list:
            print("No matching memories found.")
        else:
            print(f"Found {len(result_list)} matching memories:")
            for i, mem in enumerate(result_list, 1):
                if isinstance(mem, dict):
                    print(f"{i}. ID: {mem.get('id', 'N/A')} | Content: {mem.get('memory', 'N/A')} | Context: {mem.get('metadata', {}).get('context', 'N/A') if mem.get('metadata') else 'N/A'}")
                else:
                    print(f"{i}. Content: {mem}")
        continue
    if user_input.lower().startswith("/semantic_search "):
        query = user_input[len("/semantic_search "):].strip()
        if not query:
            print("Usage: /semantic_search <query>")
            continue
        results = semantic_search(user_id, query)
        min_cosine_distance = -0.8  # Only show results more similar than this threshold
        filtered_results = [r for r in results if r[3] is not None and r[3] < min_cosine_distance]
        if not filtered_results:
            print(f"No semantically similar messages found with cosine distance < {min_cosine_distance}.")
        else:
            print(f"Top semantically similar messages (cosine distance < {min_cosine_distance}):")
            for i, (content, role, ts, dist) in enumerate(filtered_results, 1):
                ts_str = ts.strftime('%Y-%m-%d %H:%M:%S') if ts else 'N/A'
                dist_str = f"{dist:.4f}" if dist is not None else "N/A"
                print(f"{i}. [{ts_str}] {role.capitalize()}: {content} (cosine distance: {dist_str})")
        continue
    if user_input.lower().startswith("/update "):
        parts = user_input.split(maxsplit=2)
        if len(parts) < 3:
            print("Usage: /update <memory_id> <new_content>")
            continue
        memory_id, new_content = parts[1], parts[2]
        new_context = input("Enter new context for this memory: ").strip()
        update_data = {"data": new_content, "context": new_context}
        try:
            memory.update(memory_id, update_data)
            print(f"Memory {memory_id} updated.")
        except Exception as e:
            print(f"Error updating memory: {e}")
        continue
    if user_input.lower().startswith("/delete "):
        parts = user_input.split(maxsplit=1)
        if len(parts) < 2:
            print("Usage: /delete <memory_id>")
            continue
        memory_id = parts[1]
        try:
            memory.delete(memory_id)
            print(f"Memory {memory_id} deleted.")
        except Exception as e:
            print(f"Error deleting memory: {e}")
        continue
    if user_input.lower() == "/history":
        if not history:
            print("No conversation history in this session.")
        else:
            print("Current session chat history:")
            for i, msg in enumerate(history, 1):
                ts = msg.get('timestamp')
                ts_str = ts.strftime('%Y-%m-%d %H:%M:%S') if ts else 'N/A'
                print(f"{i}. [{ts_str}] {msg['role'].capitalize()}: {msg['content']}")
        continue
    if user_input.lower() == "/clear_history":
        confirm = input("Are you sure you want to clear the current session's chat history? (y/n): ").strip().lower()
        if confirm == "y":
            history.clear()
            clear_history_db(user_id)
            print("Session chat history cleared.")
            # Optionally, prompt to clear all memories as well
            clear_mem = input("Also clear all memories for this user? (y/n): ").strip().lower()
            if clear_mem == "y":
                try:
                    memory.delete_all(user_id=user_id)
                    print("All memories for this user have been deleted.")
                except Exception as e:
                    print(f"Error clearing memories: {e}")
        else:
            print("Clear history cancelled.")
        continue
    import datetime
    now = datetime.datetime.now()
    # Add the user message to the history
    history.append({"role": "user", "content": user_input, "timestamp": now})
    save_message(user_id, "user", user_input, now)
    # Add the message to memory
    memory.add([{"role": "user", "content": user_input}], user_id=user_id)
    # Get the LLM response using the actual LangChain LLM object
    response_msg = azure_llm.invoke(history)
    # Extract the content from the AIMessage object if needed
    response = response_msg.content if hasattr(response_msg, 'content') else str(response_msg)
    now2 = datetime.datetime.now()
    # Add the assistant's response to the history
    history.append({"role": "assistant", "content": response, "timestamp": now2})
    save_message(user_id, "assistant", response, now2)
    print("Bot:", response)
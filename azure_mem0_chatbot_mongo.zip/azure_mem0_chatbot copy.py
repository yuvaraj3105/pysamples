import os
import argparse
from dotenv import load_dotenv
from mem0 import Memory
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings

# 🟢 Load environment variables from .env (if present)
load_dotenv()

# 🔑 Set Azure OpenAI LLM credentials
os.environ["AZURE_OPENAI_API_KEY"] = os.getenv("AZURE_OPENAI_API_KEY", "your-azure-openai-api-key")
os.environ["AZURE_OPENAI_ENDPOINT"] = os.getenv("AZURE_OPENAI_ENDPOINT", "your-azure-endpoint")
os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "your-deployment-name")
os.environ["AZURE_OPENAI_API_VERSION"] = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")

# 🔑 Set Azure OpenAI embedding deployment name
EMBEDDING_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME", "your-embedding-deployment-name")

# 🧠 Initialize Azure OpenAI LLM via LangChain
azure_llm = AzureChatOpenAI(
    azure_deployment=os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"],
    api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    temperature=0.1,
    max_tokens=2000
)

# 🧠 Initialize Azure OpenAI Embeddings via LangChain
azure_embeddings = AzureOpenAIEmbeddings(
    azure_deployment=EMBEDDING_DEPLOYMENT_NAME,
    api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"]
)

# 🧩 Configure mem0 to use LangChain-backed LLM and Embedder
config = {
    "llm": {
        "provider": "langchain",
        "config": {
            "model": azure_llm
        }
    },
    "embedder": {
        "provider": "langchain",
        "config": {
            "model": azure_embeddings
        }
    }
}

# 🧠 Initialize mem0 Memory
memory = Memory.from_config(config)

# 🧑‍💻 CLI Argument Parsing
parser = argparse.ArgumentParser(description="Azure OpenAI + Mem0 Chatbot")
parser.add_argument('--user-name', type=str, default='default_user', help='Username for the chat session')
args = parser.parse_args()
user_id = args.user_name

# 🌀 Conversation Loop
print("Simple Azure OpenAI + Mem0 Chatbot (type 'exit' to quit)")
history = []

while True:
    user_input = input("You: ").strip()
    if user_input.lower() == "exit":
        print("Goodbye!")
        break

    # 💬 Append user message to history and memory
    history.append({"role": "user", "content": user_input})
    memory.add([{"role": "user", "content": user_input}], user_id=user_id)

    # 🧠 Invoke LLM and get response
    response_msg = azure_llm.invoke(history)
    response = response_msg.content if hasattr(response_msg, 'content') else str(response_msg)

    # 💬 Append assistant response to history
    history.append({"role": "assistant", "content": response})
    print("Bot:", response)

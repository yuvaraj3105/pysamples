"""
azure_mem0_chatbot_mongo.py
--------------------------

A simple multi-user chatbot using Azure OpenAI (via LangChain) and Mem0 for advanced memory management, with MongoDB as the backend for chat history and memory storage.

Features:
- Multi-user support: Pass --user-name <username> via CLI to start a session for a specific user.
- Chatbot with persistent memory: Stores all user and assistant messages in MongoDB.
- **Persistent chat history across sessions using MongoDB**: Chat history is loaded from the database on startup, saved after each message, and cleared from the database on /clear_history. Each user's chat history is preserved between sessions.
- **Automatic collection creation**: If the MongoDB database or the chat_history collection do not exist, the script will create them automatically at startup.
- **/memories always reflects full chat history**: After loading chat history from the database, the script re-populates Mem0 with all past messages for the user, so /memories always shows the user's complete chat history across sessions.
- **Semantic search with vector embeddings**: Each message is stored with an embedding, and you can use /semantic_search <query> to find the most semantically similar messages in your chat history using cosine distance.
- Advanced Memory Management Commands (type in chat):
    /memories                - List all memories for the current user (reflects full chat history).
    /search <keyword>        - Search memories for the current user by keyword.
    /semantic_search <query> - Find semantically similar messages using vector search.
    /update <id> <content>   - Update a memory by its ID (will prompt for new context). Accepts both MongoDB ObjectId and UUID memory IDs, so you can use any ID shown in /memories or /search.
    /delete <id>             - Delete a memory by its ID. Accepts both MongoDB ObjectId and UUID memory IDs.
    /history                 - Show the current session's chat history (user and assistant messages).
    /clear_history           - Clear the current session's chat history (and also clears from the database; optionally, also clear all memories for the user).
    exit                     - Quit the chatbot.

Usage:
    python azure_mem0_chatbot_mongo.py --user-name alice

Example session:
    You: Hello!
    Bot: Hi there! How can I help you today?
    You: /memories
    (Lists all memories for user 'alice', including all past chat history)
    You: /search pizza
    (Lists all memories containing 'pizza')
    You: /semantic_search bmw suv
    (Lists the most semantically similar messages to 'bmw suv' using vector search)
    You: /update 12345abc New favorite food is sushi
    Enter new context for this memory: Updated after recent conversation
    (Updates memory with ID '12345abc' or a valid ObjectId)
    You: /delete 12345abc
    (Deletes memory with ID '12345abc' or a valid ObjectId)
    You: /history
    (Shows the current session's chat history)
    You: /clear_history
    (Clears the session's chat history and database history, and optionally all memories)
    You: exit
    Goodbye!

Environment variables required (can be set in .env):
- AZURE_OPENAI_API_KEY
- AZURE_OPENAI_ENDPOINT
- AZURE_OPENAI_DEPLOYMENT_NAME
- AZURE_OPENAI_API_VERSION
- AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME
- MONGODB_URI (e.g., mongodb://localhost:27017/mem0db)
- (Optional) MONGODB_DB (default: mem0db)
- (Optional) MONGODB_COLLECTION (default: chat_history)

MongoDB setup:
- The script will automatically create the database and the collection 'chat_history' if they do not exist.
- Collection schema: chat_history (user_id TEXT, role TEXT, content TEXT, embedding VECTOR, timestamp TIMESTAMP)
- The script stores vector embeddings for semantic search.

"""

import os
import sys
import argparse
import asyncio
import datetime
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from mem0 import Memory
from rich.console import Console
from motor.motor_asyncio import AsyncIOMotorClient
import numpy as np

# Load environment variables from .env if present
load_dotenv()

MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017/mem0db")
MONGODB_DB = os.getenv("MONGODB_DB", "mem0db")
MONGODB_COLLECTION = os.getenv("MONGODB_COLLECTION", "chat_history")

# Initialize MongoDB client
mongo_client = AsyncIOMotorClient(MONGODB_URI)
db = mongo_client[MONGODB_DB]
chat_collection = db[MONGODB_COLLECTION]

# Azure OpenAI setup
EMBEDDING_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME", "your-embedding-deployment-name")

azure_llm = AzureChatOpenAI(
    azure_deployment=os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"],
    api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    temperature=0.1,
    max_tokens=2000
)

azure_embeddings = AzureOpenAIEmbeddings(
    azure_deployment=EMBEDDING_DEPLOYMENT_NAME,
    api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
)

config = {
    "llm": {
        "provider": "langchain",
        "config": {
            "model": azure_llm
        }
    },
    "embedder": {
        "provider": "langchain",
        "config": {
            "model": azure_embeddings
        }
    }
}

memory = Memory.from_config(config)
console = Console()

# --- MongoDB-based chat history and memory management ---
async def load_history(user_id):
    cursor = chat_collection.find({"user_id": user_id}).sort("timestamp", 1)
    return [doc async for doc in cursor]

async def save_message(user_id, role, content, timestamp=None, memory_id=None):
    if timestamp is None:
        timestamp = datetime.datetime.now()
    embedding = get_embedding(content)
    if isinstance(embedding, np.ndarray):
        embedding = embedding.tolist()
    doc = {
        "user_id": user_id,
        "role": role,
        "content": content,
        "embedding": embedding,
        "timestamp": timestamp
    }
    if memory_id:
        doc["id"] = memory_id
    await chat_collection.insert_one(doc)

async def clear_history_db(user_id):
    await chat_collection.delete_many({"user_id": user_id})

def get_embedding(text):
    return azure_embeddings.embed_query(text)

async def semantic_search(user_id, query, top_k=5):
    embedding = get_embedding(query)
    if isinstance(embedding, np.ndarray):
        embedding = embedding.tolist()
    pipeline = [
        {"$match": {"user_id": user_id, "embedding": {"$ne": None}}},
        {"$addFields": {"cosine_distance": {"$let": {
            "vars": {"dot": {"$sum": {"$map": {"input": {"$range": [0, {"$size": "$embedding"}]}, "as": "i", "in": {"$multiply": [ {"$arrayElemAt": ["$embedding", "$$i"] }, {"$arrayElemAt": [embedding, "$$i"] } ] } } } }} ,
            "in": {"$subtract": [0, {"$divide": ["$$dot", {"$sqrt": {"$sum": {"$map": {"input": "$embedding", "as": "x", "in": {"$multiply": ["$$x", "$$x"] } } } } } ] } ] }
        }}}},
        {"$sort": {"cosine_distance": 1}},
        {"$limit": top_k},
        {"$project": {"content": 1, "role": 1, "timestamp": 1, "cosine_distance": 1}}
    ]
    results = await chat_collection.aggregate(pipeline).to_list(length=top_k)
    return results

# --- CLI argument parsing ---
parser = argparse.ArgumentParser(description="Azure OpenAI + Mem0 Chatbot (MongoDB)")
parser.add_argument('--user-name', type=str, default='default_user', help='Username for the chat session')
args, unknown = parser.parse_known_args()
user_id = args.user_name

async def main():
    # Load persistent history for this user
    history_docs = await load_history(user_id)
    history = [
        {"role": doc["role"], "content": doc["content"], "timestamp": doc["timestamp"]}
        for doc in history_docs
    ]
    # Do NOT re-populate Mem0 with all chat history on startup
    # Only add new messages to Mem0 as they are created

    console.print("Simple Azure OpenAI + Mem0 Chatbot (MongoDB, type 'exit' to quit)")

    while True:
        user_input = input("You: ").strip()
        if user_input.lower() == "exit":
            print("Goodbye!")
            break
        if user_input.lower() == "/memories":
            result = memory.get_all(user_id=user_id)
            memories = result["results"] if isinstance(result, dict) and "results" in result else result
            if not memories:
                print("No memories found for this user.")
            else:
                print(f"Found {len(memories)} memories:")
                for i, mem in enumerate(memories, 1):
                    print(f"{i}. ID: {mem.get('id', 'N/A')} | Content: {mem.get('memory', 'N/A')} | Context: {mem.get('metadata', {}).get('context', 'N/A') if mem.get('metadata') else 'N/A'}")
            continue
        if user_input.lower().startswith("/search "):
            keyword = user_input[8:].strip()
            if not keyword:
                print("Usage: /search <keyword>")
                continue
            result = memory.search(keyword, user_id=user_id)
            if isinstance(result, dict) and "results" in result:
                result_list = result["results"]
            else:
                result_list = result
            # Stricter filtering: only include if keyword in content or context (case-insensitive)
            keyword_lower = keyword.lower()
            filtered = []
            for mem in result_list:
                content = mem.get('memory', '')
                context = mem.get('metadata', {}).get('context', '') if mem.get('metadata') else ''
                if keyword_lower in content.lower() or keyword_lower in context.lower():
                    filtered.append(mem)
            if filtered:
                print(f"Found {len(filtered)} matching memories:")
                for i, mem in enumerate(filtered, 1):
                    print(f"{i}. ID: {mem.get('id', 'N/A')} | Content: {mem.get('memory', 'N/A')} | Context: {mem.get('metadata', {}).get('context', 'N/A') if mem.get('metadata') else 'N/A'}")
            elif result_list:
                # Fallback: show all results (old logic)
                print(f"No strict matches found. Showing {len(result_list)} fuzzy/partial matches:")
                for i, mem in enumerate(result_list, 1):
                    if isinstance(mem, dict):
                        print(f"{i}. ID: {mem.get('id', 'N/A')} | Content: {mem.get('memory', 'N/A')} | Context: {mem.get('metadata', {}).get('context', 'N/A') if mem.get('metadata') else 'N/A'}")
                    else:
                        print(f"{i}. Content: {mem}")
            else:
                print("No matching memories found.")
            continue
        if user_input.lower().startswith("/semantic_search "):
            query = user_input[len("/semantic_search "):].strip()
            if not query:
                print("Usage: /semantic_search <query>")
                continue
            results = await semantic_search(user_id, query)
            min_cosine_distance = -0.8
            filtered_results = [r for r in results if r.get("cosine_distance") is not None and r["cosine_distance"] < min_cosine_distance]
            if not filtered_results:
                print(f"No semantically similar messages found with cosine distance < {min_cosine_distance}.")
            else:
                print(f"Top semantically similar messages (cosine distance < {min_cosine_distance}):")
                for i, doc in enumerate(filtered_results, 1):
                    ts = doc.get("timestamp")
                    ts_str = ts.strftime('%Y-%m-%d %H:%M:%S') if ts else 'N/A'
                    dist = doc.get("cosine_distance")
                    dist_str = f"{dist:.4f}" if dist is not None else "N/A"
                    print(f"{i}. [{ts_str}] {doc['role'].capitalize()}: {doc['content']} (cosine distance: {dist_str})")
            continue
        if user_input.lower().startswith("/update "):
            parts = user_input.split(maxsplit=2)
            if len(parts) < 3:
                print("Usage: /update <memory_id> <new_content>")
                continue
            memory_id, new_content = parts[1], parts[2]
            new_context = input("Enter new context for this memory: ").strip()
            from bson.objectid import ObjectId
            from bson.errors import InvalidId
            updated = False
            # Try ObjectId first
            try:
                obj_id = ObjectId(memory_id)
                result = await chat_collection.update_one(
                    {"_id": obj_id, "user_id": user_id},
                    {"$set": {"content": new_content, "metadata.context": new_context}}
                )
                if result.modified_count > 0:
                    print(f"Memory {memory_id} updated (ObjectId).")
                    updated = True
            except InvalidId:
                pass
            # If not updated, try by 'id' field (UUID)
            if not updated:
                result = await chat_collection.update_one(
                    {"id": memory_id, "user_id": user_id},
                    {"$set": {"content": new_content, "metadata.context": new_context}}
                )
                if result.modified_count > 0:
                    print(f"Memory {memory_id} updated (UUID).")
                    updated = True
            # Optionally, update in Mem0 as well
            try:
                memory.update(memory_id, new_content, context=new_context)
            except Exception as e:
                print(f"Warning: Mem0 update failed: {e}")
            if not updated:
                print(f"No memory found with ID: {memory_id}")
            continue
        if user_input.lower().startswith("/delete "):
            parts = user_input.split(maxsplit=1)
            if len(parts) < 2:
                print("Usage: /delete <memory_id>")
                continue
            memory_id = parts[1]
            from bson.objectid import ObjectId
            from bson.errors import InvalidId
            deleted = False
            # Try ObjectId first
            try:
                obj_id = ObjectId(memory_id)
                result = await chat_collection.delete_one({"_id": obj_id, "user_id": user_id})
                if result.deleted_count > 0:
                    print(f"Memory {memory_id} deleted (ObjectId).")
                    deleted = True
            except InvalidId:
                pass
            # If not deleted, try by 'id' field (UUID)
            if not deleted:
                result = await chat_collection.delete_one({"id": memory_id, "user_id": user_id})
                if result.deleted_count > 0:
                    print(f"Memory {memory_id} deleted (UUID).")
                    deleted = True
            # Optionally, delete in Mem0 as well
            try:
                memory.delete(memory_id)
            except Exception as e:
                print(f"Warning: Mem0 delete failed: {e}")
            if not deleted:
                print(f"No memory found with ID: {memory_id}")
            continue
        if user_input.lower() == "/history":
            if not history:
                print("No conversation history in this session.")
            else:
                print("Current session chat history:")
                for i, msg in enumerate(history, 1):
                    ts = msg.get('timestamp')
                    ts_str = ts.strftime('%Y-%m-%d %H:%M:%S') if ts else 'N/A'
                    print(f"{i}. [{ts_str}] {msg['role'].capitalize()}: {msg['content']}")
            continue
        if user_input.lower() == "/clear_history":
            confirm = input("Are you sure you want to clear the current session's chat history? (y/n): ").strip().lower()
            if confirm == "y":
                history.clear()
                await clear_history_db(user_id)
                print("Session chat history cleared.")
            else:
                print("Clear history cancelled.")
            continue
        now = datetime.datetime.now()
        history.append({"role": "user", "content": user_input, "timestamp": now})
        await save_message(user_id, "user", user_input, now)
        memory.add([{ "role": "user", "content": user_input }], user_id=user_id)
        response_msg = azure_llm.invoke(history)
        response = response_msg.content if hasattr(response_msg, 'content') else str(response_msg)
        now2 = datetime.datetime.now()
        history.append({"role": "assistant", "content": response, "timestamp": now2})
        await save_message(user_id, "assistant", response, now2)
        print("Bot:", response)

if __name__ == "__main__":
    asyncio.run(main()) 
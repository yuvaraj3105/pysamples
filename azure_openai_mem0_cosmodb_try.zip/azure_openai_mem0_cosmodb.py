import os
import sys
from dotenv import load_dotenv
from mem0 import Memory
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from langchain_community.vectorstores import AzureCosmosDBVectorSearch
from azure.cosmos import CosmosClient
from azure.core.exceptions import ServiceRequestError

# --- Load Environment Variables ---
load_dotenv()
azure_openai_api_key = os.getenv("AZURE_OPENAI_API_KEY")
azure_openai_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
azure_openai_api_version = os.getenv("AZURE_OPENAI_API_VERSION")
azure_openai_deployment_name = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
azure_openai_embedding_deployment_name = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME")
cosmosdb_connection_string = os.getenv("AZURE_COSMOSDB_CONNECTION_STRING")
cosmosdb_database_name = os.getenv("AZURE_COSMOSDB_DATABASE_NAME")

# --- Function to Ensure Database Exists ---
def initialize_cosmos_db(connection_string, database_name):
    """Checks for a Cosmos DB database and creates it if it doesn't exist."""
    print(f"Checking for Cosmos DB database '{database_name}'...")
    try:
        # Initialize the Cosmos client from the connection string
        cosmos_client = CosmosClient.from_connection_string(connection_string)
        
        # Create the database if it does not exist
        database = cosmos_client.create_database_if_not_exists(id=database_name)
        print(f"Database '{database.id}' is ready.")
        return True
    except ServiceRequestError as e:
        print(f"Error connecting to Azure Cosmos DB. Check your endpoint and network: {e}", file=sys.stderr)
        return False
    except ValueError as e:
        print(f"Error with Azure Cosmos DB configuration. Check your connection string or keys: {e}", file=sys.stderr)
        return False
    except Exception as e:
        print(f"An unexpected error occurred during Cosmos DB initialization: {e}", file=sys.stderr)
        return False

# --- Connection Verification and Setup ---

# 1. Initialize and Verify Cosmos DB Database
if not initialize_cosmos_db(cosmosdb_connection_string, cosmosdb_database_name):
    sys.exit(1) # Exit if database can't be created/verified

# 2. Verify Azure OpenAI Connection
try:
    print("\nChecking connection to Azure OpenAI...")
    llm_test_client = AzureChatOpenAI(
        azure_deployment=azure_openai_deployment_name,
        api_version=azure_openai_api_version,
        azure_endpoint=azure_openai_endpoint,
        api_key=azure_openai_api_key,
        max_tokens=5
    )
    llm_test_client.invoke("test")
    print("Azure OpenAI connection successful.")
except Exception as e:
    print(f"Error connecting to Azure OpenAI: {e}", file=sys.stderr)
    sys.exit(1)


# --- Main Application Logic ---
print("\nProceeding with the main application logic...\n")

# Configuration for Mem0
config = {
    "llm": {
        "provider": "azure_openai",
        "config": {
            "model": azure_openai_deployment_name,
            "temperature": 0.1,
            "max_tokens": 2000,
            "azure_kwargs": {
                "azure_deployment": azure_openai_deployment_name,
                "api_version": azure_openai_api_version,
                "azure_endpoint": azure_openai_endpoint,
                "api_key": azure_openai_api_key
            }
        }
    },
    "embedder": {
        "provider": "azure_openai",
        "config": {
            "model": azure_openai_embedding_deployment_name,
            "azure_kwargs": {
                "api_version": azure_openai_api_version,
                "azure_deployment": azure_openai_embedding_deployment_name,
                "azure_endpoint": azure_openai_endpoint,
                "api_key": azure_openai_api_key
            }
        }
    },
    "vector_store": {
        "provider": "langchain",
        "config": {
            "client": AzureCosmosDBVectorSearch(
                collection_name="mem0",
                connection_string=cosmosdb_connection_string,
                database_name=cosmosdb_database_name,
                embedding_function=AzureOpenAIEmbeddings(
                    azure_deployment=azure_openai_embedding_deployment_name,
                    openai_api_version=azure_openai_api_version,
                    azure_endpoint=azure_openai_endpoint,
                    api_key=azure_openai_api_key
                )
            )
        }
    }
}

# Initialize Memory with the configuration
m = Memory.from_config(config)

# Example usage
messages = [
    {"role": "user", "content": "I'm planning to watch a movie tonight. Any recommendations?"},
    {"role": "assistant", "content": "How about a thriller movies? They can be quite engaging."},
    {"role": "user", "content": "I'm not a big fan of thriller movies but I love sci-fi movies."},
    {"role": "assistant", "content": "Got it! I'll avoid thriller recommendations and suggest sci-fi movies in the future."}
]

# Add memories
result = m.add(messages, user_id="alice", metadata={"category": "movies"})
print("Added memories:", result)

# Search memories
search_results = m.search("What movies does the user like?", user_id="alice")
print("Search results:", search_results)
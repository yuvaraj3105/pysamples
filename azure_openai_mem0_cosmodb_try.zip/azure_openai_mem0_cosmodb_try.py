import os
import sys
from dotenv import load_dotenv
from mem0 import Memory
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from langchain_community.vectorstores import AzureCosmosDBVectorSearch
from azure.cosmos import CosmosClient
from azure.core.exceptions import ServiceRequestError
from azure.identity import DefaultAzureCredential

# --- Load Environment Variables ---
# Make sure your .env file includes all the necessary variables
load_dotenv()

# --- Azure OpenAI Configuration ---
azure_openai_api_key = os.getenv("AZURE_OPENAI_API_KEY")
azure_openai_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
azure_openai_api_version = os.getenv("AZURE_OPENAI_API_VERSION")
azure_openai_deployment_name = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
azure_openai_embedding_deployment_name = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME")

# --- Azure Cosmos DB Configuration ---
cosmosdb_database_name = os.getenv("AZURE_COSMOSDB_DATABASE_NAME")
cosmosdb_endpoint = os.getenv("AZURE_COSMOSDB_ENDPOINT")

# --- Function to Ensure Database Exists ---
def initialize_cosmos_db(endpoint, database_name):
    """Checks for a Cosmos DB database and creates it if it doesn't exist using AAD credentials."""
    print(f"Checking for Cosmos DB database '{database_name}'...")
    try:
        # Get AAD credentials. DefaultAzureCredential will automatically look for
        # environment variables (AZURE_CLIENT_ID, etc.), managed identity, or CLI login.
        credential = DefaultAzureCredential()
        
        # Initialize the Cosmos client with the endpoint and credential
        cosmos_client = CosmosClient(url=endpoint, credential=credential)
        
        database = cosmos_client.create_database_if_not_exists(id=database_name)
        print(f"Database '{database.id}' is ready.")
        return True, credential # Return the credential for reuse
    except Exception as e:
        print(f"An unexpected error occurred during Cosmos DB initialization: {e}", file=sys.stderr)
        return False, None

# --- Connection Verification and Setup ---

# 1. Initialize and Verify Cosmos DB Database
db_ready, cosmos_credential = initialize_cosmos_db(cosmosdb_endpoint, cosmosdb_database_name)
if not db_ready:
    print("Could not initialize Cosmos DB. Exiting.", file=sys.stderr)
    sys.exit(1)

# You can add a similar check for OpenAI connection if needed

# --- Main Application Logic ---
print("\nProceeding with the main application logic...\n")

# Initialize Azure OpenAI models
llm = AzureChatOpenAI(
    azure_deployment=azure_openai_deployment_name,
    api_version=azure_openai_api_version,
    azure_endpoint=azure_openai_endpoint,
    api_key=azure_openai_api_key,
)
embedder = AzureOpenAIEmbeddings(
    azure_deployment=azure_openai_embedding_deployment_name,
    openai_api_version=azure_openai_api_version,
    azure_endpoint=azure_openai_endpoint,
    api_key=azure_openai_api_key
)


# Use the AAD credential for the LangChain vector store
cosmos_vector_store_client = AzureCosmosDBVectorSearch(
    collection_name="mem0",
    database_name=cosmosdb_database_name,
    embedding_function=embedder, # Use the embedder instance
    cosmosdb_endpoint=cosmosdb_endpoint,
    credential=cosmos_credential # Pass the credential from the initialization step
)

config = {
    "llm": {
        "provider": "langchain",
        "config": {
            "model": llm,
        }
    },
    "embedder": {
        "provider": "langchain",
        "config": {
            "model": embedder,
        }
    },
    "vector_store": {
        "provider": "langchain",
        "config": {
            "client": cosmos_vector_store_client # Use the client we just created
        }
    }
}

# --- Create Memory Instance and Use It ---
m = Memory.from_config(config)

messages = [
    {"role": "user", "content": "My favorite movies are 'The Matrix' and 'Inception'."},
    {"role": "assistant", "content": "Great choices!"},
    {"role": "user", "content": "I also love 'Blade Runner 2049'."},
    {"role": "assistant", "content": "A modern classic!"}
]

# Add memories to the store
result = m.add(messages, user_id="alice", metadata={"category": "movies"})
print("Added memories:", result)

# Search for related memories
search_results = m.search("What movies does the user like?", user_id="alice")
print("Search results:", search_results)
"""
================================================================================
Interactive Chatbot with Detailed Logging (`mem0` + Azure OpenAI)
================================================================================

Description:
------------
This script implements a robust, interactive command-line chatbot with
long-term memory, featuring detailed logging to show the internal data flow.

It uses the `mem0` library and Azure OpenAI. For each user message, it logs:
1.  The memories retrieved from `mem0` to use as context.
2.  The exact, final prompt being sent to the Azure OpenAI LLM.
3.  The user/assistant conversation pair being saved back into `mem0`.

This provides clear visibility into how memory is retrieved and used, and how
new information is stored.

Setup & Installation:
---------------------
1.  Install the required Python libraries:
    ```bash
    pip install mem0 openai python-dotenv
    ```

2.  Create a `.env` file in the same directory as this script and populate it
    with your Azure OpenAI details.

Execution:
----------
Run the script from your terminal:
    ```bash
    python your_script_name.py
    ```
    
To exit the chat, type `exit` or `quit`.

"""
import os
import json
from mem0 import Memory
from dotenv import load_dotenv

def log_step(title, data):
    """Helper function to print formatted JSON logs."""
    print("-" * 20)
    print(title)
    # Use json.dumps for pretty-printing dictionaries and lists
    print(json.dumps(data, indent=2))
    print("-" * 20)


def create_llm_prompt(user_input, memories):
    """
    Creates a detailed prompt for the LLM, including retrieved memories.
    """
    system_prompt = "You are a helpful assistant. You have a long-term memory. If you have relevant memories, use them to answer the user's question."
    
    if memories:
        # Format the memories for inclusion in the prompt
        memory_str = "\n".join([f"- {mem['memory']}" for mem in memories])
        system_prompt += f"\n\nHere are some relevant memories from our past conversations:\n{memory_str}"

    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_input},
    ]

def main():
    """
    Main function to configure and run the interactive chatbot.
    """
    load_dotenv()

    config = {
        "llm": {
            "provider": "azure_openai",
            "config": {
                "model": os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME"),
                "temperature": 0.7,
                "azure_kwargs": {
                    "api_key": os.environ.get("AZURE_OPENAI_API_KEY"),
                    "azure_endpoint": os.environ.get("AZURE_OPENAI_ENDPOINT"),
                    "api_version": os.environ.get("AZURE_OPENAI_API_VERSION"),
                    "azure_deployment": os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME"),
                }
            }
        },
        "embedder": {
            "provider": "azure_openai",
            "config": {
                "model": os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
                "azure_kwargs": {
                    "api_key": os.environ.get("AZURE_OPENAI_API_KEY"),
                    "azure_endpoint": os.environ.get("AZURE_OPENAI_ENDPOINT"),
                    "api_version": os.environ.get("AZURE_OPENAI_API_VERSION"),
                    "azure_deployment": os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
                }
            }
        }
    }

    print("Initializing chatbot with Azure OpenAI...")
    mem0_instance = Memory.from_config(config)
    user_id = "chat_user_001"
    
    print("\nChatbot is ready! Your conversation will be remembered.")
    print("Type 'exit' or 'quit' to end the session.")
    print("=" * 60)

    while True:
        try:
            user_input = input("You: ")
            if user_input.lower() in ["exit", "quit"]:
                print("Assistant: Goodbye! It was nice chatting with you.")
                break
            
            print("\n--- [START OF LOG] ---")

            # 1. Search for relevant memories
            search_results = mem0_instance.search(query=user_input, user_id=user_id)
            relevant_memories = search_results.get('results', [])
            log_step("1. MEMORIES RETRIEVED FROM mem0", relevant_memories)

            # 2. Construct a prompt with memories
            prompt_messages = create_llm_prompt(user_input, relevant_memories)
            log_step("2. PROMPT SENT TO LLM", prompt_messages)

            # 3. Call the LLM directly
            assistant_response = mem0_instance.llm.generate_response(messages=prompt_messages)
            
            # 4. Add the new exchange to long-term memory
            new_exchange = [
                {"role": "user", "content": user_input},
                {"role": "assistant", "content": assistant_response}
            ]
            mem0_instance.add(messages=new_exchange, user_id=user_id)
            log_step("3. DATA SAVED TO mem0", new_exchange)

            print("--- [END OF LOG] ---\n")

            # Display the final response to the user
            print(f"Assistant: {assistant_response}\n")

        except KeyboardInterrupt:
            print("\nAssistant: Goodbye!")
            break
        except Exception as e:
            print(f"\nAn error occurred: {e}")
            break

if __name__ == "__main__":
    main()
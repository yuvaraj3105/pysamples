"""
================================================================================
Simple Chatbot Memory Demo with `mem0` and Azure OpenAI - simple_azure_openai_mem0_example.py
================================================================================

Description:
------------
This script demonstrates a basic implementation of a long-term memory layer for
a chatbot using the `mem0` library. It is configured to use Microsoft Azure's
OpenAI service for both the language model (LLM) for processing text and the
embedding model for creating searchable vector representations of the memories.

The script performs the following actions:
1.  Loads Azure credentials and deployment details from environment variables.
2.  Configures `mem0` to use specific Azure OpenAI models.
3.  Initializes the `Memory` instance with this configuration.
4.  Adds a sample conversation to the memory for a specific user.
5.  Searches the memory with a relevant query.
6.  Prints the retrieved memories, including the memory text and its relevance score.

Prerequisites:
--------------
- Python 3.7+
- An active Azure account with access to Azure OpenAI service.
- Deployed models in Azure AI Studio for:
  - A chat/completions model (e.g., gpt-4o, gpt-35-turbo).
  - An embedding model (e.g., text-embedding-ada-002, text-embedding-3-large).

Setup & Installation:
---------------------
1.  Install the required Python libraries:
    ```bash
    pip install mem0 openai python-dotenv
    ```

2.  Create a `.env` file in the same directory as this script and populate it
    with your Azure OpenAI details. This keeps your credentials secure.
    
    Example `.env` file content:
    ```
    AZURE_OPENAI_API_KEY="YOUR_AZURE_API_KEY"
    AZURE_OPENAI_ENDPOINT="https://your-resource-name.openai.azure.com/"
    AZURE_OPENAI_API_VERSION="2024-02-15-preview"
    AZURE_OPENAI_DEPLOYMENT_NAME="your-gpt-4o-deployment-name"
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME="your-embedding-deployment-name"
    ```

Execution:
----------
Run the script from your terminal:
    ```bash
    python simple_azure_openai_mem0_example.py
    ```

"""

import os
from mem0 import Memory
from dotenv import load_dotenv

# Load environment variables from the .env file.
# This line reads the key-value pairs from your .env file and makes them
# available as environment variables.
load_dotenv()

# --- Configuration using your Azure OpenAI details ---
# This dictionary defines how mem0 should connect to the required services.
# It specifies 'azure_openai' as the provider for both the LLM and the embedder.
config = {
    "llm": {
        "provider": "azure_openai",
        "config": {
            "model": os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME"), 
            "temperature": 0.1,
            # The 'azure_kwargs' dictionary passes all necessary credentials
            # and identifiers for the Azure API.
            "azure_kwargs": {
                "api_key": os.environ.get("AZURE_OPENAI_API_KEY"),
                "azure_endpoint": os.environ.get("AZURE_OPENAI_ENDPOINT"),
                "api_version": os.environ.get("AZURE_OPENAI_API_VERSION"),
                "azure_deployment": os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME"),
            }
        }
    },
    "embedder": {
        "provider": "azure_openai",
        "config": {
            "model": os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
            "azure_kwargs": {
                "api_key": os.environ.get("AZURE_OPENAI_API_KEY"),
                "azure_endpoint": os.environ.get("AZURE_OPENAI_ENDPOINT"),
                "api_version": os.environ.get("AZURE_OPENAI_API_VERSION"),
                "azure_deployment": os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
            }
        }
    }
}

# --- Initialize mem0 and Use It ---
print("Initializing mem0 with Azure OpenAI configuration...")
m = Memory.from_config(config)

# A sample conversation to be stored in memory.
conversation = [
    {"role": "user", "content": "My favorite color is blue."},
    {"role": "assistant", "content": "Got it! I'll remember that your favorite color is blue."}
]

# The user_id ensures that memories are stored and retrieved for the correct user.
user_id = "user_1234"
print(f"Adding a new memory for user: {user_id}")
m.add(conversation, user_id=user_id)
print("Memory added successfully!\n")


# --- Search the Memory ---
query = "What is my favorite color?"
print(f"Searching memory for the query: '{query}'")

# The search function returns a dictionary containing the results.
search_results = m.search(query=query, user_id=user_id)


# --- Process and Display Results ---
# The actual list of memories is found under the 'results' key.
if search_results and search_results.get('results'):
    # Iterate over the list of memories found.
    for result in search_results['results']:
        print(f"\nFound relevant memory:")
        # Each 'result' is a dictionary containing memory details.
        # The memory text is in the 'memory' key.
        print(f"  - Text: {result['memory']}")
        # The relevance score is in the 'score' key.
        print(f"  - Score: {result['score']:.2f}")
else:
    print("No relevant memories found.")
import os
from dotenv import load_dotenv
from mem0 import Memory

# Load environment variables from .env file
load_dotenv()

config = {
    "llm": {
        "provider": "azure_openai",
        "config": {
            "model": os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
            "temperature": 0.1,
            "max_tokens": 2000,
            "azure_kwargs": {
                "azure_deployment": os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
                "api_version": os.getenv("AZURE_OPENAI_API_VERSION"),
                "azure_endpoint": os.getenv("AZURE_OPENAI_ENDPOINT"),
                "api_key": os.getenv("AZURE_OPENAI_API_KEY")
            }
        }
    },
    "embedder": {
        "provider": "azure_openai",
        "config": {
            "model": "text-embedding-ada-002",
            "azure_kwargs": {
                "api_version": os.getenv("AZURE_OPENAI_API_VERSION"),
                "azure_deployment": os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
                "azure_endpoint": os.getenv("AZURE_OPENAI_ENDPOINT"),
                "api_key": os.getenv("AZURE_OPENAI_API_KEY")
            }
        }
    },
    "vector_store": {
        "provider": "mongodb",
        "config": {
            "db_name": "mem0-db",
            "collection_name": "mem0-collection",
            "mongo_uri": os.getenv("MONGO_URI")
        }
    }
}

m = Memory.from_config(config)

# Example usage
messages = [
    {"role": "user", "content": "I'm planning to watch a movie tonight. Any recommendations?"},
    {"role": "assistant", "content": "How about thriller movies? They can be quite engaging."},
    {"role": "user", "content": "I'm not a big fan of thriller movies but I love sci-fi movies."},
    {"role": "assistant", "content": "Got it! I'll avoid thriller recommendations and suggest sci-fi movies in the future."}
]

m.add(messages, user_id="alice", metadata={"category": "movies"})
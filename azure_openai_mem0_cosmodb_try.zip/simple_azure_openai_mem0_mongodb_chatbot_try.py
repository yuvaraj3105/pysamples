"""
================================================================================
Interactive Chatbot with MongoDB Persistence (`mem0` + Azure OpenAI)
================================================================================

Description:
------------
This script implements a robust, interactive command-line chatbot with long-term,
persistent memory using MongoDB as the vector database.

The chatbot's memories are now stored in a MongoDB collection, allowing them to
survive application restarts.

How it works:
1.  Loads Azure and MongoDB credentials from a `.env` file.
2.  Initializes the `mem0` memory layer with a multi-part configuration:
    - `llm`: Uses Azure OpenAI for generating responses.
    - `embedder`: Uses Azure OpenAI for creating embeddings.
    - `vector_store`: Uses MongoDB for storing and retrieving memories.
3.  Enters an interactive loop, performing the same logic as before, but now
    all `m.search()` and `m.add()` operations interact with MongoDB.

Setup & Installation:
---------------------
1.  Install the required Python libraries, including the MongoDB extra:
    ```bash
    pip install "mem0[mongodb]" openai python-dotenv
    ```

2.  Ensure your MongoDB server is running and accessible.

3.  Create a `.env` file in the same directory as this script and populate it:
    
    Example `.env` file content:
    ```
    # Azure OpenAI Details
    AZURE_OPENAI_API_KEY="YOUR_AZURE_API_KEY"
    AZURE_OPENAI_ENDPOINT="https://your-resource-name.openai.azure.com/"
    AZURE_OPENAI_API_VERSION="2024-02-15-preview"
    AZURE_OPENAI_DEPLOYMENT_NAME="your-gpt-4o-deployment-name"
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME="your-embedding-deployment-name"
    
    # MongoDB Connection URI
    MONGO_URI="mongodb://localhost:27017/"
    ```

Execution:
----------
Run the script from your terminal:
    ```bash
    python your_script_name.py
    ```
"""
import os
import json
from mem0 import Memory
from dotenv import load_dotenv

def log_step(title, data):
    """Helper function to print formatted JSON logs."""
    print("-" * 20)
    print(title)
    print(json.dumps(data, indent=2))
    print("-" * 20)

def create_llm_prompt(user_input, memories):
    """Creates a detailed prompt for the LLM, including retrieved memories."""
    system_prompt = "You are a helpful assistant. You have a long-term memory. If you have relevant memories, use them to answer the user's question."
    if memories:
        memory_str = "\n".join([f"- {mem['memory']}" for mem in memories])
        system_prompt += f"\n\nHere are some relevant memories from our past conversations:\n{memory_str}"
    return [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_input}]

def main():
    """Main function to configure and run the interactive chatbot."""
    load_dotenv()

    # --- Configuration now includes the MongoDB vector store ---
    config = {
        "llm": {
            "provider": "azure_openai",
            "config": {
                "model": os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME"),
                "temperature": 0.7,
                "azure_kwargs": {
                    "api_key": os.environ.get("AZURE_OPENAI_API_KEY"),
                    "azure_endpoint": os.environ.get("AZURE_OPENAI_ENDPOINT"),
                    "api_version": os.environ.get("AZURE_OPENAI_API_VERSION"),
                    "azure_deployment": os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME"),
                },
            },
        },
        "embedder": {
            "provider": "azure_openai",
            "config": {
                "model": os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
                "azure_kwargs": {
                    "api_key": os.environ.get("AZURE_OPENAI_API_KEY"),
                    "azure_endpoint": os.environ.get("AZURE_OPENAI_ENDPOINT"),
                    "api_version": os.environ.get("AZURE_OPENAI_API_VERSION"),
                    "azure_deployment": os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
                },
            },
        },
        # ++++++ CORRECTED CONFIGURATION FOR MONGODB ++++++
        "vector_store": {
            "provider": "mongodb",
            "config": {
                "mongo_uri": os.environ.get("MONGO_URI"), # CORRECTED: Changed 'uri' to 'mongo_uri'
                "db_name": "mem0_chatbot_db",
                "collection_name": "memories",
                "embedding_model_dims": 1536 # ADDED: Required embedding dimensions for text-embedding-ada-002
                # REMOVED: 'index_name' is not a valid parameter here
            }
        }
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++
    }

    print("Initializing chatbot with Azure OpenAI and MongoDB...")
    mem0_instance = Memory.from_config(config)
    user_id = "chat_user_001"
    
    print("\nChatbot is ready! Your conversation will be remembered permanently in MongoDB.")
    print("Type 'exit' or 'quit' to end the session.")
    print("=" * 70)

    while True:
        try:
            user_input = input("You: ")
            if user_input.lower() in ["exit", "quit"]:
                print("Assistant: Goodbye!")
                break
            
            print("\n--- [START OF LOG] ---")

            search_results = mem0_instance.search(query=user_input, user_id=user_id)
            relevant_memories = search_results.get('results', [])
            log_step("1. MEMORIES RETRIEVED FROM MONGODB", relevant_memories)

            prompt_messages = create_llm_prompt(user_input, relevant_memories)
            log_step("2. PROMPT SENT TO LLM", prompt_messages)

            assistant_response = mem0_instance.llm.generate_response(messages=prompt_messages)
            
            new_exchange = [{"role": "user", "content": user_input}, {"role": "assistant", "content": assistant_response}]
            mem0_instance.add(messages=new_exchange, user_id=user_id)
            log_step("3. DATA SAVED TO MONGODB", new_exchange)

            print("--- [END OF LOG] ---\n")
            print(f"Assistant: {assistant_response}\n")

        except KeyboardInterrupt:
            print("\nAssistant: Goodbye!")
            break
        except Exception as e:
            print(f"\nAn error occurred: {e}")
            break

if __name__ == "__main__":
    main()


#     Of course. Let's break down the new error messages. This is a classic case of a library feature being dependent on a specific cloud service.
# Analysis of the New Errors
# You've encountered two main issues:
# $listSearchIndexes stage is only allowed on MongoDB Atlas: This is the root cause. The mem0 library's mongodb vector store is not built for a standard, local MongoDB server. It is specifically designed to use MongoDB Atlas Vector Search, which is a feature only available on MongoDB's cloud-hosted platform (Atlas). Your local MongoDB instance doesn't have this functionality, so the library fails when it tries to create or check for a vector search index.
# TypeError: MongoDB.search() got an unexpected keyword argument 'vectors': This is a downstream effect of the first error. Because the vector search index could not be created, the program enters a broken state. When you input "hi", mem0 gets the embedding vector and tries to pass it to the search function, but the underlying MongoDB store method isn't prepared to handle it because its initial setup failed.
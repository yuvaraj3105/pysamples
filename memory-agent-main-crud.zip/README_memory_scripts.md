# Memory Database Checker Scripts

These scripts help you verify and inspect memories stored in your PostgreSQL database.

## Scripts

### 1. `check_memories.py` - Check memories for a specific user

**Usage:**
```bash
# Check memories for a specific user
python check_memories.py --user Guru

# List all users with memories
python check_memories.py --list-users
```

**Features:**
- Shows all memories for a specific user
- Displays memory content, context, and timestamps
- Shows user name memory separately
- Lists all users in the database

### 2. `check_all_memories.py` - Check all memories in the database

**Usage:**
```bash
python check_all_memories.py
```

**Features:**
- Shows all memories from all users
- Groups memories by namespace (user)
- Displays memory content, context, and timestamps
- Shows total count of memories

### 3. `add_default_memories.py` - Add default memories for users

**Usage:**
```bash
# Add default memories for a specific user
python add_default_memories.py --user Guru

# Add default memories for all users
python add_default_memories.py --all-users
```

**Features:**
- Adds cricket and Demon Slayer anime preferences as default memories
- Checks for existing memories to avoid duplicates
- Can target specific users or all users

## Agent CLI Commands

### Interactive Mode
```bash
# Start interactive session with a user
python -m memory_agent --user-name Guru
```

### Direct Memory Operations
```bash
# Retrieve all memories for a user without starting a session
python -m memory_agent --retrieve-memories Guru

# Retrieve a specific memory by its ID
python -m memory_agent --retrieve-memory Guru --memory-id user_name
python -m memory_agent --retrieve-memory Guru --memory-id cricket_preference

# Update an existing memory
python -m memory_agent --update-memory Guru --memory-id cricket_preference --content "User loves cricket" --context "Updated preference"

# Add a new memory
python -m memory_agent --add-memory Guru --content "User likes pizza" --context "Food preference"

# Delete a specific memory
python -m memory_agent --delete-memory Guru --delete-memory-id cricket_preference
```

### Agent Commands (during interactive session)
- `show all memories` - Ask the agent to retrieve and display all memories
- `what do you remember about me?` - Ask the agent to recall memories
- `cricket_preference` - Ask the agent about a specific memory
- `delete the cricket_preference memory` - Ask the agent to delete a specific memory
- `add a memory about my love for pizza` - Ask the agent to add a new memory
- `update my cricket memory to say I love cricket` - Ask the agent to update an existing memory
- `quit` - Exit the session

## Environment Variables Required

Make sure these environment variables are set in your `.env` file:

```bash
PSQL_USERNAME=postgres
PSQL_PASSWORD=admin123
PSQL_HOST=localhost
PSQL_PORT=5432
PSQL_DATABASE=agent_chat
PSQL_SSLMODE=disable
```

## Example Output

### For a specific user:
```
🔍 Checking memories for user: Guru
📁 Namespace: ('memories', 'Guru')
============================================================
📚 Found 6 memories:
============================================================

🔹 Memory #1
   Key: user_name
   Created: 2025-07-14 22:12:57.188968+00:00
   Updated: 2025-07-14 22:14:50.791931+00:00
   Content: User's name is Guru
   Context: User name provided via CLI argument.
----------------------------------------

🔹 Memory #2
   Key: cricket_preference
   Content: User loves cricket and enjoys watching cricket matches.
   Context: Default memory: User has a general interest in cricket.
----------------------------------------
```

### Direct CLI retrieval:
```
📚 Memories for user 'Guru':
============================================================
Found 6 memories:
1. User's name is Guru (Context: User name provided via CLI argument.)
2. User loves Demon Slayer anime and enjoys watching anime. (Context: Default memory: User has a general interest in anime, specifically Demon Slayer.)
3. User loves cricket and enjoys watching cricket matches. (Context: Default memory: User has a general interest in cricket.)
4. Guru plans to read books on weekends. (Context: Guru shared their weekend plans.)
5. Guru likes horror movies. (Context: This was mentioned during a casual conversation about movie preferences.)
6. Guru likes sweets. (Context: Guru introduced themselves and mentioned their preference for sweets.)
============================================================
```

### Specific memory retrieval:
```
🔍 Memory 'cricket_preference' for user 'Guru':
============================================================
Memory ID: cricket_preference
Content: User loves cricket and enjoys watching cricket matches.
Context: Default memory: User has a general interest in cricket.
============================================================
```

### Memory deletion:
```
🗑️  Deleting memory 'cricket_preference' for user 'Guru':
============================================================
Successfully deleted memory 'cricket_preference' with content: User loves cricket and enjoys watching cricket matches.
============================================================
```

## Database Structure

The memories are stored in the `store` table with the following structure:

- `prefix`: Namespace (encoded as bytes, format: `memories\0user_id`)
- `key`: Memory key (UUID or special keys like "user_name", "cricket_preference", "anime_preference")
- `value`: Memory content (JSONB format with `content` and `context` fields)
- `created_at`: When the memory was created
- `updated_at`: When the memory was last updated

## Default Memories

The system automatically adds these default memories for new users:
- **cricket_preference**: "User loves cricket and enjoys watching cricket matches."
- **anime_preference**: "User loves Demon Slayer anime and enjoys watching anime."

## Troubleshooting

1. **Connection Issues**: Make sure PostgreSQL is running and environment variables are correct
2. **No Memories Found**: Check if the agent has been used to create memories
3. **Permission Issues**: Ensure the database user has read access to the `store` table

## Dependencies

- `psycopg-binary`: PostgreSQL adapter
- `python-dotenv`: Environment variable loading
- `langgraph-checkpoint-postgres`: LangGraph PostgreSQL store (for the first script) 
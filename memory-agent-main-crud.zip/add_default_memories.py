#!/usr/bin/env python3
"""
Script to add default memories for all users.
"""

import os
import asyncio
import uuid
from datetime import datetime

# Load environment variables
try:
    from dotenv import load_dotenv
    load_dotenv()
    print("✅ Environment variables loaded from .env")
except ImportError:
    print("⚠️  python-dotenv not installed. Make sure environment variables are set.")

# Import required libraries
try:
    import psycopg
    import psycopg.rows
    POSTGRES_AVAILABLE = True
except ImportError:
    POSTGRES_AVAILABLE = False
    print("❌ psycopg not available. Install with: pip install psycopg-binary")

try:
    from langgraph.store.postgres.aio import AsyncPostgresStore
    LANGGRAPH_AVAILABLE = True
except ImportError:
    LANGGRAPH_AVAILABLE = False
    print("❌ LangGraph store not available. Install with: pip install langgraph-checkpoint-postgres")


def get_pg_conn_str() -> str:
    """Get PostgreSQL connection string from environment variables."""
    username = os.getenv("PSQL_USERNAME")
    password = os.getenv("PSQL_PASSWORD")
    host = os.getenv("PSQL_HOST")
    port = os.getenv("PSQL_PORT")
    database = os.getenv("PSQL_DATABASE")
    sslmode = os.getenv("PSQL_SSLMODE", "disable")
    
    if not all([username, password, host, port, database]):
        raise ValueError("Missing required PostgreSQL env variables.")
    
    return f"postgresql://{username}:{password}@{host}:{port}/{database}?sslmode={sslmode}"


async def add_default_memories_for_user(user_id: str):
    """Add default memories for a specific user."""
    
    if not POSTGRES_AVAILABLE:
        print("❌ PostgreSQL not available")
        return False
    
    if not LANGGRAPH_AVAILABLE:
        print("❌ LangGraph store not available")
        return False
    
    try:
        # Get connection string
        conn_str = get_pg_conn_str()
        print(f"🔌 Connecting to database...")
        
        # Create async connection
        conn = await psycopg.AsyncConnection.connect(conn_str)
        
        # Create store instance
        store = AsyncPostgresStore(conn=conn)
        
        # Define the namespace for the user
        namespace = ("memories", user_id)
        print(f"🔍 Adding default memories for user: {user_id}")
        print(f"📁 Namespace: {namespace}")
        print("=" * 60)
        
        # Default memories to add
        default_memories = [
            {
                "key": "cricket_preference",
                "content": "User loves cricket and enjoys watching cricket matches.",
                "context": "Default memory: User has a general interest in cricket."
            },
            {
                "key": "anime_preference",
                "content": "User loves Demon Slayer anime and enjoys watching anime.",
                "context": "Default memory: User has a general interest in anime, specifically Demon Slayer."
            }
        ]
        
        # Check if memories already exist
        existing_memories = await store.asearch(namespace, query="cricket anime", limit=10)
        existing_keys = [mem.key for mem in existing_memories]
        
        added_count = 0
        for memory in default_memories:
            if memory["key"] not in existing_keys:
                # Add the memory
                await store.aput(
                    namespace, 
                    key=memory["key"], 
                    value={
                        "content": memory["content"],
                        "context": memory["context"]
                    }
                )
                print(f"✅ Added memory: {memory['key']}")
                print(f"   Content: {memory['content']}")
                print(f"   Context: {memory['context']}")
                print("-" * 40)
                added_count += 1
            else:
                print(f"⏭️  Memory already exists: {memory['key']}")
        
        if added_count == 0:
            print("📝 All default memories already exist for this user.")
        else:
            print(f"🎉 Successfully added {added_count} default memories!")
        
        await conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


async def add_default_memories_for_all_users():
    """Add default memories for all existing users."""
    
    if not POSTGRES_AVAILABLE:
        print("❌ PostgreSQL not available")
        return False
    
    try:
        # Get connection string
        conn_str = get_pg_conn_str()
        print(f"🔌 Connecting to database...")
        
        # Create async connection
        conn = await psycopg.AsyncConnection.connect(conn_str)
        
        # Find all users with memories
        async with conn.cursor() as cur:
            await cur.execute("""
                SELECT DISTINCT prefix
                FROM store 
                WHERE prefix LIKE E'\\x6d656d6f72696573%'
            """)
            
            results = await cur.fetchall()
            
            if not results:
                print("📭 No users found in database.")
                return True
            
            print(f"👥 Found {len(results)} users to add default memories to:")
            print("=" * 60)
            
            # Process each user
            for row in results:
                prefix_bytes = row[0]
                
                # Try to decode the prefix to get user ID
                try:
                    prefix_str = prefix_bytes.decode('utf-8', errors='ignore')
                    if '\x00' in prefix_str:
                        user_id = prefix_str.split('\x00')[1]
                    else:
                        user_id = "unknown"
                except:
                    user_id = "unknown"
                
                print(f"\n🔍 Processing user: {user_id}")
                success = await add_default_memories_for_user(user_id)
                if not success:
                    print(f"❌ Failed to add memories for user: {user_id}")
        
        await conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


async def main():
    """Main function."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Add default memories to users")
    parser.add_argument("--user", "-u", help="User ID to add default memories for")
    parser.add_argument("--all-users", "-a", action="store_true", help="Add default memories for all users")
    
    args = parser.parse_args()
    
    print("🗄️  Default Memory Adder")
    print("=" * 60)
    
    if args.all_users:
        print("📋 Adding default memories for all users...")
        success = await add_default_memories_for_all_users()
    elif args.user:
        print(f"🔍 Adding default memories for user: {args.user}")
        success = await add_default_memories_for_user(args.user)
    else:
        print("❌ Please specify --user <user_id> or --all-users")
        print("Example: python add_default_memories.py --user Guru")
        print("Example: python add_default_memories.py --all-users")
        return
    
    if success:
        print("\n✅ Operation completed successfully!")
    else:
        print("\n❌ Operation failed.")


if __name__ == "__main__":
    # Fix Windows event loop for psycopg
    import platform
    if platform.system() == "Windows":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    
    asyncio.run(main()) 
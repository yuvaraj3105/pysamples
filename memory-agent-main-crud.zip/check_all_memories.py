#!/usr/bin/env python3
"""
Simple script to check all memories in the database.
"""

import os
import asyncio
import json
from datetime import datetime

# Load environment variables
try:
    from dotenv import load_dotenv
    load_dotenv()
    print("✅ Environment variables loaded from .env")
except ImportError:
    print("⚠️  python-dotenv not installed. Make sure environment variables are set.")

# Import required libraries
try:
    import psycopg
    import psycopg.rows
    POSTGRES_AVAILABLE = True
except ImportError:
    POSTGRES_AVAILABLE = False
    print("❌ psycopg not available. Install with: pip install psycopg-binary")


def get_pg_conn_str() -> str:
    """Get PostgreSQL connection string from environment variables."""
    username = os.getenv("PSQL_USERNAME")
    password = os.getenv("PSQL_PASSWORD")
    host = os.getenv("PSQL_HOST")
    port = os.getenv("PSQL_PORT")
    database = os.getenv("PSQL_DATABASE")
    sslmode = os.getenv("PSQL_SSLMODE", "disable")
    
    if not all([username, password, host, port, database]):
        raise ValueError("Missing required PostgreSQL env variables.")
    
    return f"postgresql://{username}:{password}@{host}:{port}/{database}?sslmode={sslmode}"


async def check_all_memories():
    """Check all memories in the database."""
    
    if not POSTGRES_AVAILABLE:
        print("❌ PostgreSQL not available")
        return False
    
    try:
        # Get connection string
        conn_str = get_pg_conn_str()
        print(f"🔌 Connecting to database...")
        
        # Create async connection
        conn = await psycopg.AsyncConnection.connect(conn_str)
        
        # Query all memories
        async with conn.cursor() as cur:
            await cur.execute("""
                SELECT 
                    prefix,
                    key,
                    value,
                    created_at,
                    updated_at
                FROM store 
                ORDER BY created_at DESC
            """)
            
            results = await cur.fetchall()
            
            if not results:
                print("📭 No memories found in database.")
                return True
            
            print(f"📚 Found {len(results)} total memories:")
            print("=" * 80)
            
            # Group by prefix (namespace)
            memories_by_prefix = {}
            for row in results:
                prefix = row[0]  # prefix is the first column
                if prefix not in memories_by_prefix:
                    memories_by_prefix[prefix] = []
                memories_by_prefix[prefix].append(row)
            
            # Display memories grouped by namespace
            for prefix, memories in memories_by_prefix.items():
                print(f"\n📁 Namespace: {prefix}")
                print(f"   User ID: {decode_prefix(prefix)}")
                print(f"   Memories: {len(memories)}")
                print("-" * 60)
                
                for i, memory in enumerate(memories, 1):
                    print(f"   🔹 Memory #{i}")
                    print(f"      Key: {memory[1]}")  # key is the second column
                    print(f"      Created: {memory[3]}")  # created_at is the fourth column
                    
                    # Parse the JSON value
                    try:
                        value_data = json.loads(memory[2])  # value is the third column
                        if isinstance(value_data, dict):
                            content = value_data.get('content', 'No content')
                            context = value_data.get('context', 'No context')
                            print(f"      Content: {content}")
                            print(f"      Context: {context}")
                        else:
                            print(f"      Value: {value_data}")
                    except:
                        print(f"      Value: {memory[2]}")
                    
                    print()
        
        await conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


def decode_prefix(prefix_bytes):
    """Try to decode the prefix to get user ID."""
    try:
        # The prefix format is typically: memories\0user_id
        prefix_str = prefix_bytes.decode('utf-8', errors='ignore')
        if '\x00' in prefix_str:
            parts = prefix_str.split('\x00')
            if len(parts) >= 2:
                return parts[1]
        return "unknown"
    except:
        return "unknown"


async def main():
    """Main function."""
    print("🗄️  All Memories Database Checker")
    print("=" * 80)
    
    success = await check_all_memories()
    
    if success:
        print("\n✅ Operation completed successfully!")
    else:
        print("\n❌ Operation failed.")


if __name__ == "__main__":
    # Fix Windows event loop for psycopg
    import platform
    if platform.system() == "Windows":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    
    asyncio.run(main()) 
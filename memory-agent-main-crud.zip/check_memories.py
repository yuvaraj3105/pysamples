#!/usr/bin/env python3
"""
Script to check all memories saved in the database for a specific user.
"""

import os
import asyncio
import json
from datetime import datetime
from typing import Optional

# Load environment variables
try:
    from dotenv import load_dotenv
    load_dotenv()
    print("✅ Environment variables loaded from .env")
except ImportError:
    print("⚠️  python-dotenv not installed. Make sure environment variables are set.")

# Import required libraries
try:
    import psycopg
    import psycopg.rows
    POSTGRES_AVAILABLE = True
except ImportError:
    POSTGRES_AVAILABLE = False
    print("❌ psycopg not available. Install with: pip install psycopg-binary")

try:
    from langgraph.store.postgres.aio import AsyncPostgresStore
    LANGGRAPH_AVAILABLE = True
except ImportError:
    LANGGRAPH_AVAILABLE = False
    print("❌ LangGraph store not available. Install with: pip install langgraph-checkpoint-postgres")


def get_pg_conn_str() -> str:
    """Get PostgreSQL connection string from environment variables."""
    username = os.getenv("PSQL_USERNAME")
    password = os.getenv("PSQL_PASSWORD")
    host = os.getenv("PSQL_HOST")
    port = os.getenv("PSQL_PORT")
    database = os.getenv("PSQL_DATABASE")
    sslmode = os.getenv("PSQL_SSLMODE", "disable")
    
    if not all([username, password, host, port, database]):
        raise ValueError("Missing required PostgreSQL env variables.")
    
    return f"postgresql://{username}:{password}@{host}:{port}/{database}?sslmode={sslmode}"


async def check_memories_for_user(user_id: str):
    """Check all memories for a specific user."""
    
    if not POSTGRES_AVAILABLE:
        print("❌ PostgreSQL not available")
        return False
    
    if not LANGGRAPH_AVAILABLE:
        print("❌ LangGraph store not available")
        return False
    
    try:
        # Get connection string
        conn_str = get_pg_conn_str()
        print(f"🔌 Connecting to database...")
        
        # Create async connection
        conn = await psycopg.AsyncConnection.connect(
            conn_str, 
            row_factory=psycopg.rows.dict_row
        )
        
        # Create store instance
        store = AsyncPostgresStore(conn=conn)
        
        # Define the namespace for the user
        namespace = ("memories", user_id)
        print(f"🔍 Checking memories for user: {user_id}")
        print(f"📁 Namespace: {namespace}")
        print("=" * 60)
        
        # Search for all memories in the namespace
        memories = await store.asearch(namespace, query="*", limit=100)
        
        if not memories:
            print("📭 No memories found for this user.")
            return True
        
        print(f"📚 Found {len(memories)} memories:")
        print("=" * 60)
        
        # Display each memory
        for i, memory in enumerate(memories, 1):
            print(f"\n🔹 Memory #{i}")
            print(f"   Key: {memory.key}")
            print(f"   Created: {memory.created_at}")
            print(f"   Updated: {memory.updated_at}")
            
            # Format the value content
            if hasattr(memory, 'value') and isinstance(memory.value, dict):
                content = memory.value.get('content', 'No content')
                context = memory.value.get('context', 'No context')
                print(f"   Content: {content}")
                print(f"   Context: {context}")
            else:
                print(f"   Value: {memory.value}")
            
            print("-" * 40)
        
        # Also try to get the user name memory specifically
        try:
            name_memory = await store.aget(namespace, key="user_name")
            if name_memory:
                print(f"\n👤 User Name Memory:")
                print(f"   Key: {name_memory.key}")
                if hasattr(name_memory, 'value') and isinstance(name_memory.value, dict):
                    content = name_memory.value.get('content', 'No content')
                    print(f"   Content: {content}")
                else:
                    print(f"   Value: {name_memory.value}")
        except Exception as e:
            print(f"⚠️  Could not retrieve user name memory: {e}")
        
        await conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


async def list_all_users():
    """List all users that have memories in the database."""
    
    if not POSTGRES_AVAILABLE:
        print("❌ PostgreSQL not available")
        return False
    
    try:
        # Get connection string
        conn_str = get_pg_conn_str()
        print(f"🔌 Connecting to database...")
        
        # Create async connection
        conn = await psycopg.AsyncConnection.connect(
            conn_str, 
            row_factory=psycopg.rows.dict_row
        )
        
        # Query to find all unique prefixes (namespaces)
        async with conn.cursor() as cur:
            await cur.execute("""
                SELECT DISTINCT prefix, COUNT(*) as memory_count
                FROM store 
                WHERE prefix LIKE E'\\x6d656d6f72696573%'
                GROUP BY prefix
                ORDER BY memory_count DESC
            """)
            
            results = await cur.fetchall()
            
            if not results:
                print("📭 No user memories found in database.")
                return True
            
            print(f"👥 Found {len(results)} users with memories:")
            print("=" * 50)
            
            for row in results:
                prefix_bytes = row['prefix']
                count = row['memory_count']
                
                # Try to decode the prefix to get user ID
                try:
                    # The prefix format is typically: memories\0user_id
                    # So we split by null byte and take the second part
                    prefix_str = prefix_bytes.decode('utf-8', errors='ignore')
                    if '\x00' in prefix_str:
                        user_id = prefix_str.split('\x00')[1]
                    else:
                        user_id = "unknown"
                except:
                    user_id = "unknown"
                
                print(f"   User: {user_id} | Memories: {count}")
        
        await conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


async def main():
    """Main function."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Check memories in the database")
    parser.add_argument("--user", "-u", help="User ID to check memories for")
    parser.add_argument("--list-users", "-l", action="store_true", help="List all users with memories")
    
    args = parser.parse_args()
    
    print("🗄️  Memory Database Checker")
    print("=" * 60)
    
    if args.list_users:
        print("📋 Listing all users with memories...")
        success = await list_all_users()
    elif args.user:
        print(f"🔍 Checking memories for user: {args.user}")
        success = await check_memories_for_user(args.user)
    else:
        print("❌ Please specify --user <user_id> or --list-users")
        print("Example: python check_memories.py --user Guru")
        print("Example: python check_memories.py --list-users")
        return
    
    if success:
        print("\n✅ Operation completed successfully!")
    else:
        print("\n❌ Operation failed.")


if __name__ == "__main__":
    # Fix Windows event loop for psycopg
    import platform
    if platform.system() == "Windows":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    
    asyncio.run(main()) 
"""Enrichment for a pre-defined schema."""

import asyncio
import argparse
from typing import Optional
from memory_agent.graph import graph, get_local_graph_runner
from langchain_core.messages import HumanMessage
from memory_agent.state import State
from langchain_core.runnables import RunnableConfig
from langgraph.store.base import BaseStore
from memory_agent.tools import add_default_memories_for_user, retrieve_all_memories, retrieve_specific_memory, update_memory, add_new_memory, delete_memory

__all__ = ["graph"]


async def retrieve_memories_cli(user_id: str):
    """Retrieve all memories for a user via CLI."""
    runner = get_local_graph_runner()
    async for graph_obj, model, store in runner():
        try:
            # Create a dummy config with the user_id
            config = RunnableConfig(configurable={"user_id": user_id})
            
            # Call the retrieve function directly
            result = await retrieve_all_memories(config=config, store=store)
            print(f"\n📚 Memories for user '{user_id}':")
            print("=" * 60)
            print(result)
            print("=" * 60)
            
        except Exception as e:
            print(f"❌ Error retrieving memories: {e}")


async def retrieve_specific_memory_cli(user_id: str, memory_id: str):
    """Retrieve a specific memory for a user via CLI."""
    runner = get_local_graph_runner()
    async for graph_obj, model, store in runner():
        try:
            # Create a dummy config with the user_id
            config = RunnableConfig(configurable={"user_id": user_id})
            
            # Call the retrieve function directly
            result = await retrieve_specific_memory(memory_id=memory_id, config=config, store=store)
            print(f"\n🔍 Memory '{memory_id}' for user '{user_id}':")
            print("=" * 60)
            print(result)
            print("=" * 60)
            
        except Exception as e:
            print(f"❌ Error retrieving memory: {e}")


async def update_memory_cli(user_id: str, memory_id: str, content: str, context: str):
    """Update a specific memory for a user via CLI."""
    runner = get_local_graph_runner()
    async for graph_obj, model, store in runner():
        try:
            # Create a dummy config with the user_id
            config = RunnableConfig(configurable={"user_id": user_id})
            
            # Call the update function directly
            result = await update_memory(memory_id=memory_id, content=content, context=context, config=config, store=store)
            print(f"\n✏️  Updating memory '{memory_id}' for user '{user_id}':")
            print("=" * 60)
            print(result)
            print("=" * 60)
            
        except Exception as e:
            print(f"❌ Error updating memory: {e}")


async def add_memory_cli(user_id: str, content: str, context: str, memory_id: Optional[str] = None):
    """Add a new memory for a user via CLI."""
    runner = get_local_graph_runner()
    async for graph_obj, model, store in runner():
        try:
            # Create a dummy config with the user_id
            config = RunnableConfig(configurable={"user_id": user_id})
            
            # Call the add function directly
            result = await add_new_memory(content=content, context=context, memory_id=memory_id, config=config, store=store)
            print(f"\n➕ Adding new memory for user '{user_id}':")
            print("=" * 60)
            print(result)
            print("=" * 60)
            
        except Exception as e:
            print(f"❌ Error adding memory: {e}")


async def delete_memory_cli(user_id: str, memory_id: str):
    """Delete a specific memory for a user via CLI."""
    runner = get_local_graph_runner()
    async for graph_obj, model, store in runner():
        try:
            # Create a dummy config with the user_id
            config = RunnableConfig(configurable={"user_id": user_id})
            
            # Call the delete function directly
            result = await delete_memory(memory_id=memory_id, config=config, store=store)
            print(f"\n🗑️  Deleting memory '{memory_id}' for user '{user_id}':")
            print("=" * 60)
            print(result)
            print("=" * 60)
            
        except Exception as e:
            print(f"❌ Error deleting memory: {e}")


async def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="Memory Agent CLI")
    parser.add_argument("--user-name", "-u", type=str, help="User name for the session")
    parser.add_argument("--retrieve-memories", "-r", type=str, help="Retrieve all memories for a specific user")
    parser.add_argument("--retrieve-memory", "-m", type=str, help="Retrieve a specific memory by ID")
    parser.add_argument("--memory-id", "-i", type=str, help="Memory ID to retrieve (use with --retrieve-memory)")
    parser.add_argument("--update-memory", type=str, help="Update a specific memory by ID")
    parser.add_argument("--content", type=str, help="Content for the memory (use with --update-memory or --add-memory)")
    parser.add_argument("--context", type=str, help="Context for the memory (use with --update-memory or --add-memory)")
    parser.add_argument("--add-memory", type=str, help="Add a new memory for a user")
    parser.add_argument("--new-memory-id", type=str, help="Custom ID for new memory (optional, use with --add-memory)")
    parser.add_argument("--delete-memory", type=str, help="Delete a specific memory for a user")
    parser.add_argument("--delete-memory-id", type=str, help="Memory ID to delete (use with --delete-memory)")
    args = parser.parse_args()

    # If retrieve-memories is specified, just retrieve and exit
    if args.retrieve_memories:
        await retrieve_memories_cli(args.retrieve_memories)
        return

    # If update-memory is specified, update memory and exit
    if args.update_memory and args.content and args.context and args.memory_id:
        user_id = args.update_memory
        await update_memory_cli(user_id, args.memory_id, args.content, args.context)
        return
    elif args.update_memory:
        print("❌ --update-memory requires --memory-id, --content and --context to be specified.")
        print("Example: python -m memory_agent --update-memory Guru --memory-id cricket_preference --content 'User loves cricket' --context 'Updated preference'")
        return

    # If add-memory is specified, add memory and exit
    if args.add_memory and args.content and args.context:
        user_id = args.add_memory
        await add_memory_cli(user_id, args.content, args.context, args.new_memory_id)
        return
    elif args.add_memory:
        print("❌ --add-memory requires --content and --context to be specified.")
        print("Example: python -m memory_agent --add-memory Guru --content 'User likes pizza' --context 'Food preference'")
        return

    # If delete-memory is specified, delete memory and exit
    if args.delete_memory and args.delete_memory_id:
        await delete_memory_cli(args.delete_memory, args.delete_memory_id)
        return
    elif args.delete_memory or args.delete_memory_id:
        print("❌ Both --delete-memory and --delete-memory-id must be specified together.")
        print("Example: python -m memory_agent --delete-memory Guru --delete-memory-id cricket_preference")
        return

    # If retrieve-memory is specified, retrieve specific memory and exit
    if args.retrieve_memory and args.memory_id:
        await retrieve_specific_memory_cli(args.retrieve_memory, args.memory_id)
        return
    elif args.retrieve_memory or args.memory_id:
        print("❌ Both --retrieve-memory and --memory-id must be specified together.")
        print("Example: python -m memory_agent --retrieve-memory Guru --memory-id user_name")
        return

    runner = get_local_graph_runner()
    async for graph_obj, model, store in runner():
        print("🤖 Local Memory Agent is live! Type 'quit' to exit.")
        user_id = args.user_name if args.user_name else "local-user"
        if args.user_name:
            print(f"👤 User session: {user_id}")
            # Automatically store the CLI user name as a memory
            try:
                await store.aput(("memories", user_id), key="user_name", value={"content": f"User's name is {args.user_name}", "context": "User name provided via CLI argument."})
                print(f"[AUTO_MEMORY] Stored user name from CLI: {args.user_name}")
                
                # Add default memories for new users
                await add_default_memories_for_user(store, user_id)
                
            except Exception as e:
                print(f"[AUTO_MEMORY] Failed to store user name: {e}")
        while True:
            user_input = input("You: ").strip()
            if user_input.lower() == "quit":
                print("Goodbye!")
                break
            state = State(messages=[HumanMessage(content=user_input)])
            config = RunnableConfig(configurable={
                "user_id": user_id,
                "store": store,
                "model": model,
            })
            try:
                chunk = await graph_obj.ainvoke(state, config=config)
                # print("DEBUG CHUNK:", chunk)
                messages = chunk.get("messages", [])
                ai_messages = [m for m in messages if getattr(m, "type", None) == "ai" or m.__class__.__name__ == "AIMessage"]
                if ai_messages:
                    print(f"Agent: {ai_messages[-1].content}")
                else:
                    print("No AIMessage found in chunk. Full chunk:", chunk)
            except Exception as e:
                print("Error during graph invocation:", e)

if __name__ == "__main__":
    asyncio.run(main())

"""Graphs that extract memories on a schedule."""

import os
import logging
from datetime import datetime
import re

from langgraph.graph import END, StateGraph
from langgraph.store.base import BaseStore
from langgraph.store.postgres.aio import AsyncPostgresStore
import asyncio
from langchain_core.runnables import RunnableConfig

from memory_agent import configuration, tools, utils
from memory_agent.state import State
from memory_agent.utils import get_azure_openai_model, get_pg_conn_str

logger = logging.getLogger(__name__)

llm = None  # Will be set in local runner


async def call_model(state: State, config: RunnableConfig) -> dict:
    """Extract the user's state from the conversation and update the memory."""
    configurable = configuration.Configuration.from_runnable_config(config)
    # Extract store and model from config.configurable
    store = None
    model = None
    if isinstance(config, dict) and "configurable" in config:
        store = config["configurable"].get("store")
        model = config["configurable"].get("model")
    elif hasattr(config, "__getitem__") and "configurable" in config:
        store = config["configurable"].get("store")
        model = config["configurable"].get("model")
    # fallback for TypedDict access
    elif hasattr(config, "configurable"):
        store = getattr(config, "configurable").get("store")
        model = getattr(config, "configurable").get("model")
    if store is None:
        raise ValueError("Store must be provided for local run (not found in config.configurable).")
    if model is None:
        raise ValueError("Model must be provided for local run (not found in config.configurable).")

    user_id = configurable.user_id
    last_user_message = ""
    if state.messages and hasattr(state.messages[-1], 'content') and isinstance(state.messages[-1].content, str):
        last_user_message = state.messages[-1].content.lower()

    # --- Hot path: Store name if user says 'my name is ...' ---
    name_match = re.search(r"my name is ([a-zA-Z0-9_\- ]+)", last_user_message)
    if name_match:
        user_name = name_match.group(1).strip()
        print(f"[HOT PATH] Storing user name in memory: {user_name}")
        await store.aput(("memories", user_id), key="user_name", value={"content": f"User's name is {user_name}", "context": "User introduced themselves."})

    # --- Hot path: Recall name if user asks for it ---
    recall_name = any(q in last_user_message for q in ["what's my name", "what is my name", "do you know my name", "who am i", "whats my name"])
    memories = []
    if recall_name:
        print("[HOT PATH] User asked for their name. Attempting to recall from memory...")
        # Try to fetch the name memory directly
        try:
            name_mem = await store.aget(("memories", user_id), key="user_name")
            if name_mem:
                print(f"[HOT PATH] Recalled user name from memory: {name_mem.value}")
                memories = [name_mem]
            else:
                print("[HOT PATH] No direct name memory found. Searching all memories for 'name'.")
                memories = await store.asearch(("memories", user_id), query="name", limit=5)
        except Exception as e:
            print(f"[HOT PATH] Error fetching name memory: {e}")
            memories = await store.asearch(("memories", user_id), query="name", limit=5)
    else:
        # Default: search with last 3 messages
        memories = await store.asearch(
            ("memories", user_id),
            query=str([m.content for m in state.messages[-3:]]),
            limit=10,
        )

    # Format memories for inclusion in the prompt
    memory_texts = []
    print(f"[DEBUG] Found {len(memories)} memories")
    for mem in memories:
        if hasattr(mem, 'value') and isinstance(mem.value, dict):
            content = mem.value.get('content', str(mem.value))
            memory_texts.append(f"[{getattr(mem, 'key', 'unknown')}]: {content}")
        else:
            memory_texts.append(f"[{getattr(mem, 'key', 'unknown')}]: {mem.value}")
    
    formatted = "\n".join(memory_texts)
    print(f"[DEBUG] Formatted memories: {formatted}")
    if formatted:
        formatted = f"""
<memories>
{formatted}
</memories>"""

    # Prepare the system prompt with user memories and current time
    # This helps the model understand the context and temporal relevance
    sys = configurable.system_prompt.format(
        user_info=formatted, time=datetime.now().isoformat()
    )

    # Invoke the language model with the prepared prompt and tools
    # "bind_tools" gives the LLM the JSON schema for all tools in the list so it knows how
    # to use them.
    if model is None:
        raise ValueError("Model must be provided for local run (not found in config.configurable).")
    msg = await model.bind_tools([tools.upsert_memory, tools.retrieve_all_memories, tools.retrieve_specific_memory, tools.update_memory, tools.add_new_memory, tools.delete_memory]).ainvoke(
        [{"role": "system", "content": sys}, *state.messages],
        {"configurable": utils.split_model_and_provider(configurable.model)},
    )
    return {"messages": [msg]}


async def store_memory(state: State, config: RunnableConfig):
    # Extract tool calls from the last message
    tool_calls = state.messages[-1].tool_calls  # type: ignore[attr-defined]
    print("\n" + "-"*50)
    print(f"[STORE_MEMORY] Called with {len(tool_calls)} tool call(s):")
    for tc in tool_calls:
        print(f"[STORE_MEMORY] Tool: {tc.get('name')} | Args: {tc.get('args')}")
    print("-"*50 + "\n")
    # Extract store from config.configurable
    store = None
    if isinstance(config, dict) and "configurable" in config:
        store = config["configurable"].get("store")
    elif hasattr(config, "__getitem__") and "configurable" in config:
        store = config["configurable"].get("store")
    elif hasattr(config, "configurable"):
        store = getattr(config, "configurable").get("store")
    if store is None:
        raise ValueError("Store must be provided for local run (not found in config.configurable).")

    # Execute tool calls based on the tool name
    tool_results = []
    for tc in tool_calls:
        tool_name = tc.get("name")
        if tool_name == "upsert_memory":
            result = await tools.upsert_memory(**tc["args"], config=config, store=store)
        elif tool_name == "retrieve_all_memories":
            result = await tools.retrieve_all_memories(config=config, store=store)
        elif tool_name == "retrieve_specific_memory":
            result = await tools.retrieve_specific_memory(**tc["args"], config=config, store=store)
        elif tool_name == "update_memory":
            result = await tools.update_memory(**tc["args"], config=config, store=store)
        elif tool_name == "add_new_memory":
            result = await tools.add_new_memory(**tc["args"], config=config, store=store)
        elif tool_name == "delete_memory":
            result = await tools.delete_memory(**tc["args"], config=config, store=store)
        else:
            result = f"Unknown tool: {tool_name}"
        
        tool_results.append(result)

    # Format the results of tool operations
    # This provides confirmation to the model that the actions it took were completed
    results = [
        {
            "role": "tool",
            "content": result,
            "tool_call_id": tc["id"],
        }
        for tc, result in zip(tool_calls, tool_results)
    ]
    return {"messages": results}


def route_message(state: State):
    """Determine the next step based on the presence of tool calls."""
    msg = state.messages[-1]
    print("\n" + "*"*50)
    print(f"[ROUTE_MESSAGE] Last message type: {type(msg).__name__}")
    has_tool_calls = hasattr(msg, 'tool_calls') and getattr(msg, 'tool_calls', None)
    print(f"[ROUTE_MESSAGE] tool_calls present: {bool(has_tool_calls)}")
    print("*"*50 + "\n")
    if msg.tool_calls:  # type: ignore[attr-defined]
        # If there are tool calls, we need to store memories
        return "store_memory"
    # Otherwise, finish; user can send the next message
    return END


# Create the graph + all nodes
builder = StateGraph(State, config_schema=configuration.Configuration)

# Define the flow of the memory extraction process
builder.add_node(call_model)
builder.add_edge("__start__", "call_model")
builder.add_node(store_memory)
builder.add_conditional_edges("call_model", route_message, ["store_memory", END])
# Right now, we're returning control to the user after storing a memory
# Depending on the model, you may want to route back to the model
# to let it first store memories, then generate a response
builder.add_edge("store_memory", "call_model")
graph = builder.compile()
graph.name = "MemoryAgent"


def get_local_graph_runner():
    """Initialize the graph runner for local development with Azure OpenAI and Postgres."""
    # Load environment variables if using dotenv
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass

    # Initialize model and store
    model = get_azure_openai_model()
    pg_conn_str = get_pg_conn_str()
    store = AsyncPostgresStore.from_conn_string(pg_conn_str)
    # Return a coroutine that yields the graph, model, and store
    async def runner():
        async with store as s:
            await s.setup()
            yield graph, model, s
    return runner


__all__ = ["graph"]

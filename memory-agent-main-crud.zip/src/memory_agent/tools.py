"""Define he agent's tools."""

import uuid
from typing import Annotated, Optional

from langchain_core.runnables import RunnableConfig
from langchain_core.tools import InjectedToolArg
from langgraph.store.base import BaseStore

from memory_agent.configuration import Configuration


async def upsert_memory(
    content: str,
    context: str,
    *,
    memory_id: Optional[uuid.UUID] = None,
    # Hide these arguments from the model.
    config: Annotated[RunnableConfig, InjectedToolArg],
    store: Annotated[BaseStore, InjectedToolArg],
):
    """Upsert a memory in the database.

    If a memory conflicts with an existing one, then just UPDATE the
    existing one by passing in memory_id - don't create two memories
    that are the same. If the user corrects a memory, UPDATE it.

    Args:
        content: The main content of the memory. For example:
            "User expressed interest in learning about French."
        context: Additional context for the memory. For example:
            "This was mentioned while discussing career options in Europe."
        memory_id: ONLY PROVIDE IF UPDATING AN EXISTING MEMORY.
        The memory to overwrite.
    """
    mem_id = memory_id or uuid.uuid4()
    user_id = Configuration.from_runnable_config(config).user_id
    print("\n" + "="*50)
    print(f"[UPSERT_MEMORY] Upserting memory for user_id={user_id}")
    print(f"[UPSERT_MEMORY] Content: {content}")
    print(f"[UPSERT_MEMORY] Context: {context}")
    print("="*50 + "\n")
    await store.aput(
        ("memories", user_id),
        key=str(mem_id),
        value={"content": content, "context": context},
    )
    return f"Stored memory {mem_id}"


async def update_memory(
    memory_id: str,
    content: str,
    context: str,
    # Hide these arguments from the model.
    config: Annotated[RunnableConfig, InjectedToolArg],
    store: Annotated[BaseStore, InjectedToolArg],
):
    """Update an existing memory in the database.

    Args:
        memory_id: The ID of the memory to update.
        content: The new content of the memory.
        context: The new context for the memory.
    """
    user_id = Configuration.from_runnable_config(config).user_id
    namespace = ("memories", user_id)
    
    try:
        # Check if the memory exists
        existing_memory = await store.aget(namespace, key=memory_id)
        
        if not existing_memory:
            return f"Memory with ID '{memory_id}' not found for user '{user_id}'."
        
        # Update the memory
        await store.aput(
            namespace,
            key=memory_id,
            value={"content": content, "context": context},
        )
        
        return f"Successfully updated memory '{memory_id}' with new content: {content}"
        
    except Exception as e:
        return f"Error updating memory '{memory_id}': {e}"


async def add_new_memory(
    content: str,
    context: str,
    # Hide these arguments from the model.
    config: Annotated[RunnableConfig, InjectedToolArg],
    store: Annotated[BaseStore, InjectedToolArg],
    memory_id: Optional[str] = None,
):
    """Add a new memory to the database.

    Args:
        content: The content of the new memory.
        context: The context for the new memory.
        memory_id: Optional custom ID for the memory. If not provided, a UUID will be generated.
    """
    user_id = Configuration.from_runnable_config(config).user_id
    namespace = ("memories", user_id)
    
    try:
        # Generate memory ID if not provided
        if not memory_id:
            memory_id = str(uuid.uuid4())
        
        # Check if memory with this ID already exists
        existing_memory = await store.aget(namespace, key=memory_id)
        
        if existing_memory:
            return f"Memory with ID '{memory_id}' already exists for user '{user_id}'. Use update_memory to modify existing memories."
        
        # Add the new memory
        await store.aput(
            namespace,
            key=memory_id,
            value={"content": content, "context": context},
        )
        
        return f"Successfully added new memory '{memory_id}' with content: {content}"
        
    except Exception as e:
        return f"Error adding new memory: {e}"


async def delete_memory(
    memory_id: str,
    # Hide these arguments from the model.
    config: Annotated[RunnableConfig, InjectedToolArg],
    store: Annotated[BaseStore, InjectedToolArg],
):
    """Delete a specific memory by its ID.

    Args:
        memory_id: The ID of the memory to delete.
    """
    user_id = Configuration.from_runnable_config(config).user_id
    namespace = ("memories", user_id)
    
    try:
        # Check if the memory exists
        existing_memory = await store.aget(namespace, key=memory_id)
        
        if not existing_memory:
            return f"Memory with ID '{memory_id}' not found for user '{user_id}'."
        
        # Get the memory content for confirmation message
        memory_content = "Unknown content"
        if hasattr(existing_memory, 'value') and isinstance(existing_memory.value, dict):
            memory_content = existing_memory.value.get('content', 'Unknown content')
        
        # Delete the memory
        await store.adelete(namespace, memory_id)
        
        return f"Successfully deleted memory '{memory_id}' with content: {memory_content}"
        
    except Exception as e:
        return f"Error deleting memory '{memory_id}': {e}"


async def retrieve_all_memories(
    # Hide these arguments from the model.
    config: Annotated[RunnableConfig, InjectedToolArg],
    store: Annotated[BaseStore, InjectedToolArg],
):
    """Retrieve all memories for the current user.

    Returns a formatted string with all memories for the user.
    """
    user_id = Configuration.from_runnable_config(config).user_id
    namespace = ("memories", user_id)
    
    try:
        # Search for all memories in the namespace
        memories = await store.asearch(namespace, query="*", limit=100)
        
        if not memories:
            return "No memories found for this user."
        
        # Format the memories
        memory_texts = []
        for i, memory in enumerate(memories, 1):
            if hasattr(memory, 'value') and isinstance(memory.value, dict):
                content = memory.value.get('content', 'No content')
                context = memory.value.get('context', 'No context')
                memory_texts.append(f"{i}. {content} (Context: {context})")
            else:
                memory_texts.append(f"{i}. {memory.value}")
        
        formatted_memories = "\n".join(memory_texts)
        return f"Found {len(memories)} memories:\n{formatted_memories}"
        
    except Exception as e:
        return f"Error retrieving memories: {e}"


async def retrieve_specific_memory(
    memory_id: str,
    # Hide these arguments from the model.
    config: Annotated[RunnableConfig, InjectedToolArg],
    store: Annotated[BaseStore, InjectedToolArg],
):
    """Retrieve a specific memory by its ID.

    Args:
        memory_id: The ID of the memory to retrieve.
    """
    user_id = Configuration.from_runnable_config(config).user_id
    namespace = ("memories", user_id)
    
    try:
        # Try to get the specific memory
        memory = await store.aget(namespace, key=memory_id)
        
        if not memory:
            return f"Memory with ID '{memory_id}' not found for user '{user_id}'."
        
        # Format the memory
        if hasattr(memory, 'value') and isinstance(memory.value, dict):
            content = memory.value.get('content', 'No content')
            context = memory.value.get('context', 'No context')
            return f"Memory ID: {memory_id}\nContent: {content}\nContext: {context}"
        else:
            return f"Memory ID: {memory_id}\nValue: {memory.value}"
        
    except Exception as e:
        return f"Error retrieving memory '{memory_id}': {e}"


async def add_default_memories_for_user(store: BaseStore, user_id: str):
    """Add default memories for a new user."""
    try:
        namespace = ("memories", user_id)
        # Default memories to add
        default_memories = [
            {
                "key": "cricket_preference",
                "content": "User loves cricket and enjoys watching cricket matches.",
                "context": "Default memory: User has a general interest in cricket."
            },
            {
                "key": "anime_preference",
                "content": "User loves Demon Slayer anime and enjoys watching anime.",
                "context": "Default memory: User has a general interest in anime, specifically Demon Slayer."
            }
        ]
        # Check if memories already exist
        existing_memories = await store.asearch(namespace, query="cricket anime", limit=10)
        existing_keys = [mem.key for mem in existing_memories]
        added_count = 0
        for memory in default_memories:
            if memory["key"] not in existing_keys:
                await store.aput(
                    namespace,
                    key=memory["key"],
                    value={
                        "content": memory["content"],
                        "context": memory["context"]
                    }
                )
                print(f"[AUTO_MEMORY] Added default memory: {memory['key']}")
                added_count += 1
        if added_count > 0:
            print(f"[AUTO_MEMORY] Added {added_count} default memories for new user")
    except Exception as e:
        print(f"[AUTO_MEMORY] Failed to add default memories: {e}")

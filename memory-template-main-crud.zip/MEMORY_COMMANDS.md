# Memory Management Commands

This document lists all supported memory management commands for both the CLI and interactive chat modes in this project.

---

## CLI Commands

All CLI commands are run using:

```bash
python -m chatbot --user-name <username> <command>
```

### 1. List All Memories
- **Description:** List all memories for the user.
- **Usage:**
  ```bash
  python -m chatbot --user-name <username> --list-memories
  ```
- **Example:**
  ```bash
  python -m chatbot --user-name guru --list-memories
  ```

### 2. Get a Memory by ID
- **Description:** Retrieve a specific memory by its ID.
- **Usage:**
  ```bash
  python -m chatbot --user-name <username> --get-memory <memory_id>
  ```
- **Example:**
  ```bash
  python -m chatbot --user-name guru --get-memory 12345
  ```

### 3. Delete a Memory by ID
- **Description:** Delete a specific memory by its ID.
- **Usage:**
  ```bash
  python -m chatbot --user-name <username> --delete-memory <memory_id>
  ```
- **Example:**
  ```bash
  python -m chatbot --user-name guru --delete-memory 12345
  ```

### 4. Update a Memory by ID
- **Description:** Update a memory's value by its ID. The new value must be a valid JSON string.
- **Usage:**
  ```bash
  python -m chatbot --user-name <username> --update-memory <memory_id> '{"key": "new value"}'
  ```
- **Example:**
  ```bash
  python -m chatbot --user-name guru --update-memory 12345 '{"content": "Updated note."}'
  ```

### 5. Add to a Memory by ID
- **Description:** Add (merge/append) data to a memory's value by its ID. The data must be a valid JSON string.
- **Usage:**
  ```bash
  python -m chatbot --user-name <username> --add-to-memory <memory_id> '{"extra": "data"}'
  ```
- **Example:**
  ```bash
  python -m chatbot --user-name guru --add-to-memory 12345 '{"tag": "important"}'
  ```

---

## Chat Commands

Type these commands during an interactive chat session (after starting the bot with `python -m chatbot --user-name <username>`):

### 1. List All Memories
- **Command:**
  ```
  /list_memories
  ```

### 2. Get a Memory by ID
- **Command:**
  ```
  /get_memory <memory_id>
  ```
  **Example:**
  ```
  /get_memory 12345
  ```

### 3. Delete a Memory by ID
- **Command:**
  ```
  /delete_memory <memory_id>
  ```
  **Example:**
  ```
  /delete_memory 12345
  ```

### 4. Update a Memory by ID
- **Command:**
  ```
  /update_memory <memory_id> {"key": "new value"}
  ```
  **Example:**
  ```
  /update_memory 12345 {"content": "Updated note."}
  ```

### 5. Add to a Memory by ID
- **Command:**
  ```
  /add_to_memory <memory_id> {"extra": "data"}
  ```
  **Example:**
  ```
  /add_to_memory 12345 {"tag": "important"}
  ```

---

## Onboarding / Default Memories
- When a new user is detected (no existing memories), the system automatically adds a default note and a default user profile.
- This is handled automatically; no command is needed.

---

## Notes
- For update/add commands, the value must be a valid JSON string.
- Memory IDs can be found using the list command.
- All commands are case-sensitive and should be typed exactly as shown. 
# LangGraph Memory Service

[![CI](https://github.com/langchain-ai/memory-template/actions/workflows/unit-tests.yml/badge.svg)](https://github.com/langchain-ai/memory-template/actions/workflows/unit-tests.yml)
[![Integration Tests](https://github.com/langchain-ai/memory-template/actions/workflows/integration-tests.yml/badge.svg)](https://github.com/langchain-ai/memory-template/actions/workflows/integration-tests.yml)

---

## Overview

The **LangGraph Memory Service** is a template for building and deploying a long-term memory service for AI applications. It enables your AI agents to learn from user interactions, adapt to personal preferences, and remember important information across sessions. The service is modular, customizable, and integrates easily with LangGraph agents and Studio.

![Motivation](./static/memory_motivation.png)

---

## Features

- **Long-term, user-scoped memory** for AI agents
- **Customizable memory schemas** (profile, notes, events, etc.)
- **Efficient, debounced memory updates** (background jobs)
- **Separation of chatbot and memory logic**
- **Easy integration** with LangGraph Studio and SDK
- **Multiple LLM provider support** (Anthropic, OpenAI, etc.)

---

## Installation

### 1. Clone the Repository

```bash
git clone <your-repo-url>
cd memory-template-main
```

### 2. Set Up a Virtual Environment (Recommended)

```bash
python3 -m venv my-venv
source my-venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -e .
```

### 4. Set Up Environment Variables

```bash
cp .env.example .env
```

Edit `.env` and add your API keys for the LLM provider you want to use (Anthropic or OpenAI):

```
ANTHROPIC_API_KEY=your-anthropic-key
# or
OPENAI_API_KEY=your-openai-key
```

---

## Usage

### 1. Run the Chatbot

```bash
python -m chatbot --user-name <username>
```

Replace `<username>` with your desired user name.

### 2. Try It Out in LangGraph Studio

- Open the template in [LangGraph Studio](https://langgraph-studio.vercel.app/templates/open?githubUrl=https://github.com/langchain-ai/memory-template).
- Navigate to the `chatbot` graph.
- Chat with the bot and observe how it forms and recalls memories.

### 3. Deploy to the Cloud

For cloud deployment, follow the instructions in the [LangGraph Cloud documentation](https://langchain-ai.github.io/langgraph/cloud/).

---

## Memory Management: How It Works

### Key Concepts

- **Memory Types:** Define what information to track using customizable JSON schemas (e.g., User profile, Notes).
- **Update Modes:**
  - `patch`: Updates a single JSON document (e.g., user profile).
  - `insert`: Adds new memories to a collection (e.g., notes, events).
- **Debouncing:** Memory updates are scheduled after each chatbot response. If another message arrives before the update, the previous update is canceled and rescheduled. This ensures efficient, timely memory formation.
- **Storage:** Memories are stored namespaced by user and schema type.

### Memory Flow

![Flow](./static/memory_template_flow.png)

### Debouncing and Scheduling

After each chatbot response, the system schedules a memory update. If the user sends another message before the update, the previous update is canceled and a new one is scheduled. This is implemented in the memory scheduler:

![Debounce](./static/scheduling.png)

### Memory Types and Schemas

You can define any custom memory schema. Two defaults are provided:

#### User Profile (Patch Mode)

```json
{
  "name": "User",
  "description": "Update this document to maintain up-to-date information about the user in the conversation.",
  "update_mode": "patch",
  "parameters": {
    "type": "object",
    "properties": {
      "user_name": { "type": "string" },
      "age": { "type": "integer" },
      "interests": { "type": "array", "items": { "type": "string" } },
      "home": { "type": "string" },
      "occupation": { "type": "string" },
      "conversation_preferences": { "type": "array", "items": { "type": "string" } }
    }
  }
}
```

#### Note/Event (Insert Mode)

```json
{
  "name": "Note",
  "description": "Save notable memories the user has shared with you for later recall.",
  "update_mode": "insert",
  "parameters": {
    "type": "object",
    "properties": {
      "context": { "type": "string" },
      "content": { "type": "string" }
    },
    "required": ["context", "content"]
  }
}
```

### Memory Storage and Namespacing

All memories are stored in a persistent backend, namespaced by user and memory type. This allows efficient retrieval and isolation of user data.

![Memory Types](./static/memory_types.png)

### Memory Update Logic

- **Patch Mode:**
  - Maintains a single up-to-date document per user (e.g., profile).
  - Updates are applied as JSON patches, minimizing information loss and token cost.
- **Insert Mode:**
  - Adds new memory entries for each notable event or fact.
  - Enables tracking of multiple, distinct pieces of information.

#### Example: Patch Update

```python
# Pseudocode for patch update
if not memory_exists:
    create_new_memory()
else:
    apply_patch_to_existing_memory()
```

#### Example: Insert Update

```python
# Pseudocode for insert update
for new_fact in extracted_facts:
    insert_new_memory_entry(new_fact)
```

### Memory Service as a Graph

The memory management logic is implemented as a LangGraph graph. Each memory type is processed in parallel, and updates are scheduled and applied efficiently.

![Interaction Pattern](./static/memory_interactions.png)

---

## Customization

- **Add or Modify Memory Schemas:** Edit the memory schemas in the configuration to track different types of information.
- **Change LLM Provider/Model:** Set the `model` in your configuration (e.g., `openai:gpt-4`).
- **Customize Prompts:** Update the prompts in the graph definition or configuration.

---

## Evaluation and Testing

- Use the provided test cases in `tests/integration_tests/test_graph.py` to evaluate memory extraction and update logic.
- Example test (patch mode):

```python
@pytest.mark.asyncio
async def test_patch_memory_stored():
    ...
    await graph.ainvoke({"messages": [("user", "My name is Bob. I like fun things")]}, config)
    ...
    assert mem.value.get("preferred_name") == "Bob"
```

- Example test (insert mode):

```python
@pytest.mark.asyncio
async def test_insertion_memory_stored():
    ...
    await graph.ainvoke({"messages": [ ... ]}, config)
    ...
    assert any("Joanne" in mem.value.get("name", "") for mem in memories)
```

---

## Project Structure

- `src/`: Source code for the chatbot and memory graph
- `tests/`: Test cases and evaluation scripts
- `static/`: Images and diagrams for documentation
- `README.md`: This documentation file
- `pyproject.toml`: Python project configuration

---

## License

This project is licensed under the MIT License.


PYTHONPATH=src python -m chatbot --user-name manu
"""An example chatbot that connects to the memory processor graph."""
import asyncio
import argparse
from typing import Optional
from langchain_core.messages import HumanMessage
from langchain_core.runnables import RunnableConfig
from langgraph.store.postgres.aio import AsyncPostgresStore

from chatbot.graph import graph
from chatbot.configuration import ChatConfigurable
from chatbot.utils import format_memories, store_user_memory
from chatbot.memory_utils import add_default_memories_for_user, get_memory_by_id, get_all_memories_for_user, delete_memory_by_id, update_memory_by_id, add_to_memory_by_id


async def extract_memories_from_conversation(store, model, user_id: str, user_input: str):
    """Extract and store memories from the conversation using the memory_graph."""
    try:
        print(f"\n{'='*60}")
        print(f"[MEMORY_EXTRACTION] 🔄 Starting memory extraction for user: {user_id}")
        print(f"[MEMORY_EXTRACTION] Input: {user_input}")
        print(f"[MEMORY_EXTRACTION] Calling the actual memory_graph as described in README")
        print(f"{'='*60}")
        
        # Import and call the actual memory_graph
        from memory_graph.graph import graph as memory_graph
        from memory_graph import configuration
        
        # Create the memory extraction state
        memory_state = {"messages": [HumanMessage(content=user_input)]}
        
        # Pass the actual Azure OpenAI model instance
        memory_config = RunnableConfig(configurable={
            "user_id": user_id,
            "model": model,
            "store": store,  # Pass the store instance to the memory graph
        })
        
        print(f"[MEMORY_EXTRACTION] 🚀 Invoking memory_graph with Azure OpenAI model instance")
        print(f"[MEMORY_EXTRACTION] This will process User and Note schemas as described in README")
        
        # Run the actual memory_graph
        await memory_graph.ainvoke(memory_state, config=memory_config)
        
        print(f"[MEMORY_EXTRACTION] ✅ Memory graph processing completed")
        print(f"[MEMORY_EXTRACTION] User schema (patch mode) and Note schema (insert mode) processed")
        print(f"[MEMORY_EXTRACTION] LLM has analyzed conversation and updated memory schemas")
        print(f"{'='*60}")
        
    except Exception as e:
        print(f"[MEMORY_EXTRACTION] ❌ Error in memory_graph processing: {e}")
        print(f"[MEMORY_EXTRACTION] Falling back to simple pattern matching...")
        
        # Fallback to simple pattern matching if memory_graph fails
        user_input_lower = user_input.lower()
        
        # Extract name if mentioned (User schema - patch mode)
        if "my name is" in user_input_lower:
            import re
            name_match = re.search(r"my name is ([a-zA-Z0-9_\- ]+)", user_input_lower)
            if name_match:
                name = name_match.group(1).strip()
                print(f"[FALLBACK] 👤 Processing User schema (patch mode)")
                print(f"[FALLBACK] Extracted user_name: {name}")
                await store_user_memory(store, user_id, f"User's name is {name}", "User introduced themselves", "user_name")
        
        # Extract interests and preferences (Note schema - insert mode)
        interest_keywords = ["like", "love", "enjoy", "prefer", "favorite"]
        for keyword in interest_keywords:
            if keyword in user_input_lower:
                parts = user_input_lower.split(keyword)
                if len(parts) > 1:
                    interest = parts[1].strip()
                    if interest and len(interest) > 2:
                        print(f"[FALLBACK] 📝 Processing Note schema (insert mode)")
                        print(f"[FALLBACK] Extracted interest: {interest}")
                        await store_user_memory(store, user_id, f"User {keyword}s {interest}", f"User mentioned this in conversation", f"interest_{keyword}_{len(interest)}")
                        break


async def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="Memory Template Chatbot CLI")
    parser.add_argument("--user-name", "-u", type=str, help="User name for the session")
    parser.add_argument("--get-memory", type=str, help="Retrieve a memory by its ID and print it, then exit.")
    parser.add_argument("--list-memories", action="store_true", help="List all memories for the user and print them, then exit.")
    parser.add_argument("--delete-memory", type=str, help="Delete a memory by its ID and print the result, then exit.")
    parser.add_argument("--update-memory", nargs=2, metavar=("ID", "JSON_VALUE"), help="Update a memory by its ID with a new JSON value, then exit.")
    parser.add_argument("--add-to-memory", nargs=2, metavar=("ID", "JSON_VALUE"), help="Add to a memory by its ID with a new JSON value, then exit.")
    args = parser.parse_args()

    # Load environment variables
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass

    # Import utils here to avoid module-level calls
    from memory_graph import utils
    
    # Get PostgreSQL connection and Azure OpenAI model
    conn_str = utils.get_pg_conn_str()
    store = AsyncPostgresStore.from_conn_string(conn_str)
    model = utils.get_azure_openai_model()

    print("🤖 Memory Template Chatbot is live! Type 'quit' to exit.")
    user_id = args.user_name if args.user_name else "local-user"
    if args.user_name:
        print(f"👤 User session: {user_id}")

    async with store as s:
        await s.setup()
        
        # CLI: List all memories for user and exit if requested
        if args.list_memories:
            print(f"[MEMORY_LIST] 📋 Listing all memories for user '{user_id}'")
            memories_str = await get_all_memories_for_user(s, user_id)
            print(memories_str)
            return

        # CLI: Retrieve memory by ID and exit if requested
        if args.get_memory:
            print(f"[MEMORY_RETRIEVAL] 🔍 Retrieving memory for user '{user_id}' with ID: {args.get_memory}")
            memory = await get_memory_by_id(s, user_id, args.get_memory)
            if memory:
                print(f"[MEMORY_RETRIEVAL] ✅ Memory found:\n{memory}")
            else:
                print(f"[MEMORY_RETRIEVAL] ❌ No memory found with ID: {args.get_memory}")
            return

        # CLI: Delete memory by ID and exit if requested
        if args.delete_memory:
            print(f"[MEMORY_DELETE] 🗑️ Deleting memory for user '{user_id}' with ID: {args.delete_memory}")
            deleted = await delete_memory_by_id(s, user_id, args.delete_memory)
            if deleted:
                print(f"[MEMORY_DELETE] ✅ Memory deleted: {args.delete_memory}")
            else:
                print(f"[MEMORY_DELETE] ❌ No memory found with ID: {args.delete_memory}")
            return

        # CLI: Update memory by ID and exit if requested
        if args.update_memory:
            memory_id, json_value = args.update_memory
            import json
            try:
                new_value = json.loads(json_value)
            except Exception as e:
                print(f"[MEMORY_UPDATE] ❌ Invalid JSON value: {e}")
                return
            print(f"[MEMORY_UPDATE] ✏️ Updating memory for user '{user_id}' with ID: {memory_id}")
            updated = await update_memory_by_id(s, user_id, memory_id, new_value)
            if updated:
                print(f"[MEMORY_UPDATE] ✅ Memory updated: {memory_id}")
            else:
                print(f"[MEMORY_UPDATE] ❌ No memory found with ID: {memory_id}")
            return
        # CLI: Add to memory by ID and exit if requested
        if args.add_to_memory:
            memory_id, json_value = args.add_to_memory
            import json
            try:
                data_to_add = json.loads(json_value)
            except Exception as e:
                print(f"[MEMORY_ADD] ❌ Invalid JSON value: {e}")
                return
            print(f"[MEMORY_ADD] ➕ Adding to memory for user '{user_id}' with ID: {memory_id}")
            updated = await add_to_memory_by_id(s, user_id, memory_id, data_to_add)
            if updated:
                print(f"[MEMORY_ADD] ✅ Memory updated: {memory_id}")
            else:
                print(f"[MEMORY_ADD] ❌ No memory found with ID: {memory_id}")
            return

        # Store the user name if provided
        if args.user_name:
            try:
                print(f"\n{'='*60}")
                print(f"[INITIAL_SETUP] 🚀 Setting up initial user memory")
                print(f"[INITIAL_SETUP] Storing user name in User schema (patch mode)")
                print(f"[INITIAL_SETUP] Namespace: ('memories', '{user_id}')")
                print(f"{'='*60}")
                await s.aput(("memories", user_id), key="user_name", value={"content": f"User's name is {args.user_name}", "context": "User name provided via CLI argument."})
                print(f"[AUTO_MEMORY] ✅ Stored user name from CLI: {args.user_name}")
                # Check if user is new (no memories in ('memories', user_id))
                existing = await s.asearch(("memories", user_id), query="*", limit=1)
                if not existing:
                    print(f"[ONBOARDING] 🆕 New user detected. Adding default memories...")
                    await add_default_memories_for_user(s, user_id)
                    print(f"[ONBOARDING] ✅ Default note and profile added for user: {user_id}")
            except Exception as e:
                print(f"[AUTO_MEMORY] ❌ Failed to store user name: {e}")

        while True:
            user_input = input("You: ").strip()
            if user_input.lower() == "quit":
                print("Goodbye!")
                break
            
            if not user_input:
                continue

            # Chat command: /get_memory <id>
            if user_input.startswith("/get_memory "):
                memory_id = user_input[len("/get_memory "):].strip()
                print(f"[MEMORY_RETRIEVAL] 🔍 Retrieving memory for user '{user_id}' with ID: {memory_id}")
                memory = await get_memory_by_id(s, user_id, memory_id)
                if memory:
                    print(f"[MEMORY_RETRIEVAL] ✅ Memory found:\n{memory}")
                else:
                    print(f"[MEMORY_RETRIEVAL] ❌ No memory found with ID: {memory_id}")
                continue

            # Chat command: /list_memories
            if user_input.strip() == "/list_memories":
                print(f"[MEMORY_LIST] 📋 Listing all memories for user '{user_id}'")
                memories_str = await get_all_memories_for_user(s, user_id)
                print(memories_str)
                continue

            # Chat command: /delete_memory <id>
            if user_input.startswith("/delete_memory "):
                memory_id = user_input[len("/delete_memory "):].strip()
                print(f"[MEMORY_DELETE] 🗑️ Deleting memory for user '{user_id}' with ID: {memory_id}")
                deleted = await delete_memory_by_id(s, user_id, memory_id)
                if deleted:
                    print(f"[MEMORY_DELETE] ✅ Memory deleted: {memory_id}")
                else:
                    print(f"[MEMORY_DELETE] ❌ No memory found with ID: {memory_id}")
                continue

            # Chat command: /update_memory <id> <json_value>
            if user_input.startswith("/update_memory "):
                import json
                try:
                    _, memory_id, json_value = user_input.split(" ", 2)
                    new_value = json.loads(json_value)
                except Exception as e:
                    print(f"[MEMORY_UPDATE] ❌ Usage: /update_memory <id> <json_value> (error: {e})")
                    continue
                print(f"[MEMORY_UPDATE] ✏️ Updating memory for user '{user_id}' with ID: {memory_id}")
                updated = await update_memory_by_id(s, user_id, memory_id, new_value)
                if updated:
                    print(f"[MEMORY_UPDATE] ✅ Memory updated: {memory_id}")
                else:
                    print(f"[MEMORY_UPDATE] ❌ No memory found with ID: {memory_id}")
                continue
            # Chat command: /add_to_memory <id> <json_value>
            if user_input.startswith("/add_to_memory "):
                import json
                try:
                    _, memory_id, json_value = user_input.split(" ", 2)
                    data_to_add = json.loads(json_value)
                except Exception as e:
                    print(f"[MEMORY_ADD] ❌ Usage: /add_to_memory <id> <json_value> (error: {e})")
                    continue
                print(f"[MEMORY_ADD] ➕ Adding to memory for user '{user_id}' with ID: {memory_id}")
                updated = await add_to_memory_by_id(s, user_id, memory_id, data_to_add)
                if updated:
                    print(f"[MEMORY_ADD] ✅ Memory updated: {memory_id}")
                else:
                    print(f"[MEMORY_ADD] ❌ No memory found with ID: {memory_id}")
                continue

            # Extract memories from the conversation using memory_graph
            await extract_memories_from_conversation(s, model, user_id, user_input)

            # Create state with user message
            from chatbot.graph import ChatState
            state = ChatState(messages=[HumanMessage(content=user_input)])
            
            # Create config with store and model
            config = RunnableConfig(configurable={
                "user_id": user_id,
                "store": s,
                "model": model,
            })
            
            try:
                # Run the chatbot graph
                result = await graph.ainvoke(state, config=config)
                messages = result.get("messages", [])
                
                # Find AI messages in the response
                ai_messages = [m for m in messages if getattr(m, "type", None) == "ai" or m.__class__.__name__ == "AIMessage"]
                if ai_messages:
                    print(f"Assistant: {ai_messages[-1].content}")
                else:
                    print("No response generated.")
                    
            except Exception as e:
                print(f"Error during conversation: {e}")
                import traceback
                traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())

"""Example chatbot that incorporates user memories."""

import datetime
import re
import asyncio
from dataclasses import dataclass
import logging

from langchain_core.runnables import RunnableConfig
from langgraph.graph import StateGraph
from langgraph.graph.message import Messages, add_messages
from typing_extensions import Annotated

from chatbot.configuration import ChatConfigurable
from chatbot.utils import format_memories


@dataclass
class ChatState:
    """The state of the chatbot."""

    messages: Annotated[list[Messages], add_messages]
    step_count: int = 0  # Add step counter to state


async def bot(state: ChatState, config: RunnableConfig) -> dict[str, list[Messages]]:
    """Bot that responds to the user, incorporating memories from PostgreSQL."""
    logger = logging.getLogger("chatbot.graph")
    logger.info(f"[NODE ENTRY] Entering bot node. Step: {state.step_count}")
    if state.step_count > 100:
        logger.error("[RUNAWAY DETECTION] Step count exceeded 100 in bot node. Aborting.")
        raise RuntimeError("Step count exceeded 100. Possible runaway/cycle detected.")
    # Extract store and model from config
    store = config["configurable"].get("store")
    model = config["configurable"].get("model")
    user_id = config["configurable"].get("user_id", "default-user")
    
    if not store or not model:
        raise ValueError("Store and model must be provided in config")
    
    # Get the last user message for hot path processing
    last_user_message = ""
    if state.messages and hasattr(state.messages[-1], 'content') and isinstance(state.messages[-1].content, str):
        last_user_message = state.messages[-1].content.lower()
    
    print(f"\n{'='*60}")
    print(f"[MEMORY_SERVICE] Processing user message: {last_user_message}")
    print(f"[MEMORY_SERVICE] User ID: {user_id}")
    print(f"{'='*60}")
    
    # --- Hot path: Store name if user says 'my name is ...' ---
    name_match = re.search(r"my name is ([a-zA-Z0-9_\- ]+)", last_user_message)
    if name_match:
        user_name = name_match.group(1).strip()
        print(f"[HOT_PATH] 🔥 Direct name extraction: {user_name}")
        print(f"[HOT_PATH] Storing in User schema (patch mode)")
        await store.aput(("memories", user_id), key="user_name", value={"content": f"User's name is {user_name}", "context": "User introduced themselves."})
    
    # --- Hot path: Recall name if user asks for it ---
    recall_name = any(q in last_user_message for q in ["what's my name", "what is my name", "do you know my name", "who am i", "whats my name"])
    memories = []
    
    if recall_name:
        print(f"[HOT_PATH] 🔥 Direct name recall requested")
        print(f"[HOT_PATH] Searching User schema namespace: ('memories', '{user_id}')")
        # Try to fetch the name memory directly
        try:
            name_mem = await store.aget(("memories", user_id), key="user_name")
            if name_mem:
                print(f"[HOT_PATH] ✅ Found name memory: {name_mem.value}")
                memories = [name_mem]
            else:
                print(f"[HOT_PATH] ⚠️ No direct name memory found, searching all memories for 'name'")
                memories = await store.asearch(("memories", user_id), query="name", limit=5)
        except Exception as e:
            print(f"[HOT_PATH] ❌ Error fetching name memory: {e}")
            memories = await store.asearch(("memories", user_id), query="name", limit=5)
    else:
        # Search for relevant memories - try multiple namespaces
        print(f"[MEMORY_RETRIEVAL] 🔍 Searching for relevant memories...")
        namespaces_to_try = [
            ("memories", user_id),
            ("memories", user_id, "User"),
            ("memories", user_id, "Note"),
        ]
        
        query = "\n".join(str(message.content) for message in state.messages[-3:])
        print(f"[MEMORY_RETRIEVAL] Query: {query}")
        
        for namespace in namespaces_to_try:
            try:
                print(f"[MEMORY_RETRIEVAL] Searching namespace: {namespace}")
                items = await store.asearch(namespace, query=query, limit=10)
                if items:
                    print(f"[MEMORY_RETRIEVAL] ✅ Found {len(items)} memories in {namespace}")
                    memories.extend(items)
                else:
                    print(f"[MEMORY_RETRIEVAL] ⚠️ No memories found in {namespace}")
            except Exception as e:
                print(f"[MEMORY_RETRIEVAL] ❌ Error searching {namespace}: {e}")
        
        # Also try to get all memories for this user using asearch instead of alist
        try:
            print(f"[MEMORY_RETRIEVAL] 🔍 Searching all memories for user...")
            all_items = await store.asearch(("memories", user_id), query="*", limit=100)
            print(f"[MEMORY_RETRIEVAL] ✅ Found {len(all_items)} total memories")
            memories.extend(all_items)
        except Exception as e:
            print(f"[MEMORY_RETRIEVAL] ❌ Error searching all memories: {e}")
    
    # Format memories for the prompt
    user_info = format_memories(memories)
    print(f"[MEMORY_FORMATTING] 📝 Formatted {len(memories)} memories for prompt")
    
    # Create system prompt
    system_prompt = f"""You are a helpful assistant that remembers information about users.

You have access to the following memories about the user:
{user_info}

Current time: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

Use the information above to provide personalized responses. If the user shares new information, try to remember it for future conversations."""

    print(f"[SYSTEM_PROMPT] 🤖 Created system prompt with {len(memories)} memories")

    # Create messages for the model
    messages = [{"role": "system", "content": system_prompt}]
    for msg in state.messages:
        if hasattr(msg, 'content'):
            messages.append({
                "role": "user" if msg.__class__.__name__ == "HumanMessage" else "assistant",
                "content": msg.content
            })
    
    # Get response from model
    print(f"[MODEL_INVOCATION] 🧠 Invoking model with {len(messages)} messages")
    response = await model.ainvoke(messages)
    print(f"[MODEL_RESPONSE] ✅ Model response generated")
    logger.info("[NODE EXIT] Exiting bot node.")
    # Increment step_count for next node
    return {"messages": [response], "step_count": state.step_count + 1}


async def schedule_memories(state: ChatState, config: RunnableConfig) -> None:
    """Schedule memory processing with debouncing (as described in README)."""
    logger = logging.getLogger("chatbot.graph")
    logger.info(f"[NODE ENTRY] Entering schedule_memories node. Step: {state.step_count}")
    if state.step_count > 100:
        logger.error("[RUNAWAY DETECTION] Step count exceeded 100 in schedule_memories node. Aborting.")
        raise RuntimeError("Step count exceeded 100. Possible runaway/cycle detected.")
    print(f"\n{'='*60}")
    print(f"[DEBOUNCING] ⏰ Scheduling memory extraction...")
    print(f"[DEBOUNCING] This implements the debouncing mechanism described in README")
    print(f"[DEBOUNCING] Memory updates are delayed to avoid redundant processing")
    print(f"[DEBOUNCING] If user sends another message soon, this will be cancelled")
    # Get the debouncing delay from config
    delay_seconds = 3
    try:
        from chatbot.configuration import ChatConfigurable
        delay_seconds = ChatConfigurable.from_context().delay_seconds
    except Exception:
        pass
    print(f"[DEBOUNCING] Debounce delay before saving memories: {delay_seconds} seconds")
    print(f"[DEBOUNCING] Processing after period of inactivity (conversation segment end)")
    print(f"{'='*60}")
    # Simulate the debouncing delay
    await asyncio.sleep(delay_seconds)
    print(f"[MEMORY_EXTRACTION] 🔄 Starting memory extraction process...")
    print(f"[MEMORY_EXTRACTION] This would trigger the memory_graph to extract memories")
    print(f"[MEMORY_EXTRACTION] Using User schema (patch mode) and Note schema (insert mode)")
    print(f"[MEMORY_EXTRACTION] LLM will analyze conversation and update memory schemas")
    print(f"[MEMORY_EXTRACTION] Process complete - memories updated in database")
    print(f"[INFO] Memory processing scheduled (simplified for local run)")
    logger.info("[NODE EXIT] Exiting schedule_memories node.")
    state.step_count += 1


builder = StateGraph(ChatState)
builder.add_node("bot", bot)
builder.add_node("schedule_memories", schedule_memories)

builder.add_edge("__start__", "bot")
builder.add_edge("bot", "schedule_memories")

graph = builder.compile()

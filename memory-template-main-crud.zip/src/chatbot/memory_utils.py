"""Default memories utilities for onboarding new users."""
import uuid
from typing import Any

async def add_default_memories_for_user(store: Any, user_id: str):
    """
    Add both a default note and a default user profile for a new user.
    This should be called after user creation if the user has no existing memories.
    """
    await add_default_note(store, user_id)
    await add_default_profile(store, user_id)

async def add_default_note(store: Any, user_id: str):
    """
    Add a default welcome note and a sample interest note for a new user.
    """
    default_notes = [
        {
            "content": "Welcome to the chatbot! You can ask me anything or tell me about your interests.",
            "context": "System-generated welcome message"
        },
        {
            "content": "The user is interested in technology and learning new things.",
            "context": "Default interest"
        }
    ]
    notes_namespace = ("memories", user_id, "Note")
    for note in default_notes:
        key = str(uuid.uuid4())
        await store.aput(notes_namespace, key, note)

async def add_default_profile(store: Any, user_id: str):
    """
    Add a default user profile for a new user.
    """
    user_profile = {
        "user_name": user_id,
        "interests": ["technology", "learning"],
        "home": "",
        "occupation": "",
        "conversation_preferences": []
    }
    await store.aput(("memories", user_id, "User"), "current", user_profile)

async def get_memory_by_id(store, user_id: str, memory_id: str):
    """
    Retrieve a specific memory by its ID for a given user.

    Args:
        store: The memory store instance.
        user_id: The user whose memory to retrieve.
        memory_id: The ID of the memory to retrieve.
    Returns:
        The memory dict if found, else None.
    """
    namespace = ("memories", user_id)
    # Search for the memory with the given ID
    results = await store.asearch(namespace, query="", limit=100)
    for memory in results:
        if memory.get("id") == memory_id:
            return memory
    return None

async def get_all_memories_for_user(store, user_id: str) -> str:
    """
    Retrieve all memories for the current user.

    Args:
        store: The memory store instance.
        user_id: The user whose memories to retrieve.
    Returns:
        A formatted string with all memories for the user.
    """
    namespace = ("memories", user_id)
    results = await store.asearch(namespace, query="", limit=100)
    if not results:
        return f"No memories found for user '{user_id}'."
    formatted = [f"ID: {m.get('id', '<no id>')} | Key: {m.get('key', '<no key>')} | Value: {m.get('value', {})}" for m in results]
    return "\n".join(formatted)

async def delete_memory_by_id(store, user_id: str, memory_id: str) -> bool:
    """
    Delete a specific memory by its ID for a given user.

    Args:
        store: The memory store instance.
        user_id: The user whose memory to delete.
        memory_id: The ID of the memory to delete.
    Returns:
        True if the memory was deleted, False if not found.
    """
    namespace = ("memories", user_id)
    results = await store.asearch(namespace, query="", limit=100)
    for memory in results:
        if memory.get("id") == memory_id:
            await store.adelete(namespace, memory_id)
            return True
    return False

async def update_memory_by_id(store, user_id: str, memory_id: str, new_value) -> bool:
    """
    Update an existing memory's value by its ID for a given user.

    Args:
        store: The memory store instance.
        user_id: The user whose memory to update.
        memory_id: The ID of the memory to update.
        new_value: The new value to set for the memory.
    Returns:
        True if the memory was updated, False if not found.
    """
    namespace = ("memories", user_id)
    results = await store.asearch(namespace, query="", limit=100)
    for memory in results:
        if memory.get("id") == memory_id:
            await store.aput(namespace, memory_id, new_value)
            return True
    return False

async def add_to_memory_by_id(store, user_id: str, memory_id: str, data_to_add) -> bool:
    """
    Add (merge/append) new data to an existing memory's value by its ID for a given user.

    Args:
        store: The memory store instance.
        user_id: The user whose memory to update.
        memory_id: The ID of the memory to update.
        data_to_add: The data to merge/append to the memory's value.
    Returns:
        True if the memory was updated, False if not found.
    """
    namespace = ("memories", user_id)
    results = await store.asearch(namespace, query="", limit=100)
    for memory in results:
        if memory.get("id") == memory_id:
            value = memory.get("value", {})
            # Merge dictionaries or append to lists if possible
            if isinstance(value, dict) and isinstance(data_to_add, dict):
                value.update(data_to_add)
            elif isinstance(value, list) and isinstance(data_to_add, list):
                value.extend(data_to_add)
            else:
                # Fallback: just replace
                value = data_to_add
            await store.aput(namespace, memory_id, value)
            return True
    return False 
"""Define utility functions for your graph."""
import os
import uuid
from typing import Optional
from langchain_openai import AzureChatOpenAI
from langgraph.store.base import Item

def get_azure_openai_model():
    """Initialize Azure OpenAI model with environment variables."""
    return AzureChatOpenAI(
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        api_version="2024-02-15-preview",
        model="gpt-4o",
        temperature=0.7,
    )

async def store_user_memory(store, user_id: str, content: str, context: str = "", memory_key: str = None):
    """Store a user memory in the database."""
    try:
        if not memory_key:
            memory_key = str(uuid.uuid4())
        
        print(f"[MEMORY_STORAGE] 💾 Storing memory in database...")
        print(f"[MEMORY_STORAGE] Key: {memory_key}")
        print(f"[MEMORY_STORAGE] Content: {content}")
        print(f"[MEMORY_STORAGE] Context: {context}")
        print(f"[MEMORY_STORAGE] Namespace: ('memories', '{user_id}')")
        
        await store.aput(
            ("memories", user_id),
            key=memory_key,
            value={"content": content, "context": context}
        )
        print(f"[MEMORY_STORAGE] ✅ Successfully stored memory: {content}")
        return True
    except Exception as e:
        print(f"[MEMORY_STORAGE] ❌ Failed to store memory: {e}")
        return False

def format_memories(memories: Optional[list[Item]]) -> str:
    """Format the user's memories."""
    if not memories:
        print(f"[MEMORY_FORMATTING] ⚠️ No memories found for user")
        return "No memories found for this user."
    
    print(f"[MEMORY_FORMATTING] 📝 Formatting {len(memories)} memories for prompt...")
    formatted_memories = []
    for i, memory in enumerate(memories, 1):
        try:
            # Handle different memory formats
            if hasattr(memory, 'value'):
                value = memory.value
                if isinstance(value, dict):
                    # Handle structured memory data
                    if 'content' in value:
                        content = value['content']
                        context = value.get('context', '')
                        formatted_memories.append(f"- {content} (Context: {context})")
                        print(f"[MEMORY_FORMATTING] Memory {i}: {content}")
                    else:
                        formatted_memories.append(f"- {str(value)}")
                        print(f"[MEMORY_FORMATTING] Memory {i}: {str(value)}")
                else:
                    formatted_memories.append(f"- {str(value)}")
                    print(f"[MEMORY_FORMATTING] Memory {i}: {str(value)}")
            else:
                formatted_memories.append(f"- {str(memory)}")
                print(f"[MEMORY_FORMATTING] Memory {i}: {str(memory)}")
        except Exception as e:
            print(f"[MEMORY_FORMATTING] ⚠️ Could not format memory {i}: {e}")
            formatted_memories.append(f"- {str(memory)}")
    
    if not formatted_memories:
        print(f"[MEMORY_FORMATTING] ⚠️ No valid memories to format")
        return "No memories found for this user."
    
    print(f"[MEMORY_FORMATTING] ✅ Successfully formatted {len(formatted_memories)} memories")
    return f"""
## Memories
You have noted the following memorable events from previous interactions with the user:
{chr(10).join(formatted_memories)}
"""

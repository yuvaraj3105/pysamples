"""Enrichment for a pre-defined schema."""

from memory_graph.graph import graph

__all__ = ["graph"]

"""Graphs that extract memories on a schedule."""
from __future__ import annotations

import asyncio
import functools
import logging
from typing import Any

from langchain_core.messages import AnyMessage
from langgraph.func import entrypoint, task
from langgraph.graph import add_messages
from langmem import create_memory_store_manager
from typing_extensions import Annotated, TypedDict

from memory_graph import configuration


class State(TypedDict):
    """The state of the graph."""

    messages: Annotated[list[AnyMessage], add_messages]
    """The messages in the conversation."""
    step_count: int  # Add step counter to state


class ProcessorState(State):
    """Extractor state."""

    function_name: str


logger = logging.getLogger(__name__)


@functools.lru_cache(maxsize=100)
def get_store_manager(function_name: str, store=None):
    configurable = configuration.Configuration.from_context()
    memory_config = next(
        conf for conf in configurable.memory_types if conf.name == function_name
    )

    print(f"\n{'='*60}")
    print(f"[MEMORY_GRAPH] 🔧 Initializing memory store manager")
    print(f"[MEMORY_GRAPH] Memory type: {function_name}")
    print(f"[MEMORY_GRAPH] Update mode: {memory_config.update_mode}")
    print(f"[MEMORY_GRAPH] Description: {memory_config.description}")
    print(f"[MEMORY_GRAPH] Namespace: ('memories', '{{user_id}}', '{function_name}')")
    print(f"{'='*60}")

    kwargs: dict[str, Any] = {
        "enable_inserts": memory_config.update_mode == "insert",
    }
    if memory_config.system_prompt:
        kwargs["instructions"] = memory_config.system_prompt

    # Use the store if provided, else try to get from context/config
    if store is None:
        try:
            from langgraph.config import get_store
            store = get_store()
        except Exception:
            store = None
    return create_memory_store_manager(
        configurable.model,
        namespace=("memories", "{user_id}", function_name),
        store=store,
        **kwargs,
    )


@task()
async def process_memory_type(state: ProcessorState, store=None) -> None:
    """Extract the user's state from the conversation and update the memory."""
    logger = logging.getLogger("memory_graph.graph")
    logger.info(f"[NODE ENTRY] Entering process_memory_type node for {state['function_name']}. Step: {state.get('step_count', 0)}")
    if state.get('step_count', 0) > 100:
        logger.error(f"[RUNAWAY DETECTION] Step count exceeded 100 in process_memory_type node for {state['function_name']}. Aborting.")
        raise RuntimeError("Step count exceeded 100. Possible runaway/cycle detected.")
    configurable = configuration.Configuration.from_context()
    function_name = state["function_name"]

    # Try to get store from config context if not explicitly passed
    if store is None:
        import langgraph.config
        config = langgraph.config.get_config()
        if config and "configurable" in config and config["configurable"].get("store") is not None:
            store = config["configurable"]["store"]

    print(f"\n{'='*60}")
    print(f"[MEMORY_GRAPH] 🔄 Processing memory type: {function_name}")
    print(f"[MEMORY_GRAPH] User ID: {configurable.user_id}")
    print(f"[MEMORY_GRAPH] Model: {configurable.model}")
    print(f"[MEMORY_GRAPH] Messages to process: {len(state['messages'])}")
    print(f"[MEMORY_GRAPH] Max extraction steps: {configurable.max_extraction_steps}")
    print(f"{'='*60}")

    # Get the memory store manager for this memory type
    store_manager = get_store_manager(function_name, store=store)

    print(f"[MEMORY_GRAPH] 🧠 Invoking LLM for memory extraction...")
    print(f"[MEMORY_GRAPH] This is where the LLM analyzes the conversation")
    print(f"[MEMORY_GRAPH] LLM will extract memories based on the schema")

    try:
        result = await asyncio.wait_for(
            store_manager.ainvoke(
                {"messages": state["messages"], "max_steps": configurable.max_extraction_steps},
                config={
                    "configurable": {
                        "model": configurable.model,
                        "user_id": configurable.user_id,
                        "store": store,  # Pass store in config for downstream use
                    },
                },
            ),
            timeout=30  # seconds
        )
        # Deduplication logic for Note (insert) memories
        memory_config = next(
            conf for conf in configurable.memory_types if conf.name == function_name
        )
        if memory_config.update_mode == "insert" and hasattr(store_manager, 'store') and isinstance(result, list):
            # Fetch existing notes' content
            notes_namespace = ("memories", configurable.user_id, function_name)
            existing_notes = await store_manager.store.asearch(notes_namespace, query="", limit=100)
            def normalize(text):
                return text.strip().lower() if text else ""
            existing_contents = {normalize(note['value'].get('content')) for note in existing_notes if 'value' in note and 'content' in note['value']}
            # Log extracted notes for debugging
            print(f"[MEMORY_GRAPH] Extracted notes from LLM (before deduplication):")
            for memory in result:
                print(f"  - {memory.get('value', {}).get('content')}")
            # Only insert notes whose normalized content is not already present
            new_notes = [memory for memory in result if normalize(memory.get('value', {}).get('content')) not in existing_contents]
            if not new_notes:
                print(f"[MEMORY_GRAPH] No new notes to insert for {function_name}. Stopping extraction for this memory type.")
                logger.info(f"[MEMORY_GRAPH] No new notes to insert for {function_name}. Stopping extraction for this memory type.")
                return
            for memory in new_notes:
                await store_manager.store.aput(
                    memory['namespace'],
                    memory['key'],
                    memory['value']
                )
                logger.info(f"[MEMORY EXTRACTION] Manually persisted new unique memory: {memory}")
            print(f"[MEMORY_GRAPH] ✅ Deduplicated and inserted {len(new_notes)} new notes (out of {len(result)})")
        elif hasattr(store_manager, 'store') and isinstance(result, list):
            for memory in result:
                await store_manager.store.aput(
                    memory['namespace'],
                    memory['key'],
                    memory['value']
                )
                logger.info(f"[MEMORY EXTRACTION] Manually persisted memory: {memory}")
        print(f"[MEMORY_GRAPH] ✅ Successfully processed {function_name} memories")
        print(f"[MEMORY_GRAPH] Memories have been stored/updated in the database")
    except asyncio.TimeoutError:
        print(f"[MEMORY_GRAPH] ❌ Timeout: Memory extraction took too long and was cancelled.")
    except Exception as e:
        print(f"[MEMORY_GRAPH] ❌ Error processing {function_name} memories: {e}")
        import traceback
        traceback.print_exc()
    logger.info(f"[NODE EXIT] Exiting process_memory_type node for {state['function_name']}")
    if 'step_count' in state:
        state['step_count'] += 1


@entrypoint(config_schema=configuration.Configuration)
async def graph(state: State) -> None:
    """Iterate over all memory types in the configuration.

    It will route each memory type from configuration to the corresponding memory update node.

    The memory update nodes will be executed in parallel.
    """
    logger = logging.getLogger("memory_graph.graph")
    logger.info(f"[NODE ENTRY] Entering memory_graph main entrypoint. Step: {state.get('step_count', 0)}")
    if state.get('step_count', 0) > 100:
        logger.error("[RUNAWAY DETECTION] Step count exceeded 100 in memory_graph main entrypoint. Aborting.")
        raise RuntimeError("Step count exceeded 100. Possible runaway/cycle detected.")
    if not state["messages"]:
        raise ValueError("No messages provided")
    
    configurable = configuration.Configuration.from_context()
    
    print(f"\n{'='*60}")
    print(f"[MEMORY_GRAPH] 🚀 Starting memory graph processing")
    print(f"[MEMORY_GRAPH] User ID: {configurable.user_id}")
    print(f"[MEMORY_GRAPH] Model: {configurable.model}")
    print(f"[MEMORY_GRAPH] Memory types to process: {len(configurable.memory_types)}")
    for i, memory_type in enumerate(configurable.memory_types, 1):
        print(f"[MEMORY_GRAPH]   {i}. {memory_type.name} ({memory_type.update_mode} mode)")
    print(f"[MEMORY_GRAPH] Messages: {len(state['messages'])}")
    print(f"[MEMORY_GRAPH] This is the main memory extraction process described in README")
    print(f"{'='*60}")
    
    # Process all memory types in parallel
    print(f"[MEMORY_GRAPH] 🔄 Processing memory types in parallel...")
    await asyncio.gather(
        *[
            process_memory_type(
                ProcessorState(messages=state["messages"], function_name=v.name),
            )
            for v in configurable.memory_types
        ]
    )
    
    print(f"[MEMORY_GRAPH] ✅ Memory graph processing complete")
    print(f"[MEMORY_GRAPH] All memory types have been processed")
    print(f"[MEMORY_GRAPH] Database has been updated with new memories")
    print(f"{'='*60}")
    logger.info("[NODE EXIT] Exiting memory_graph main entrypoint.")
    if 'step_count' in state:
        state['step_count'] += 1


__all__ = ["graph"]


# Local runner for testing with PostgreSQL and Azure OpenAI
async def local_runner():
    """Runner for testing the memory graph with PostgreSQL and Azure OpenAI."""
    import os
    from dotenv import load_dotenv
    
    # Load environment variables
    load_dotenv()
    
    # Get PostgreSQL connection string
    from memory_graph import utils
    conn_str = utils.get_pg_conn_str()
    print(f"Using PostgreSQL connection: {conn_str}")
    
    # Get Azure OpenAI model
    model = utils.get_azure_openai_model()
    print("Using Azure OpenAI model")
    
    # Example conversation
    messages = [
        {"role": "user", "content": "Hello! My name is John and I'm a software engineer."}
    ]
    
    print("Running memory graph...")
    print(f"Input messages: {messages}")
    
    # Run the graph
    try:
        result = await graph.ainvoke({"messages": messages})
        print("Result:", result)
    except Exception as e:
        print(f"Error running graph: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(local_runner())

"""Utility functions used in our graph."""

from typing import Sequence

from langchain_core.messages import AnyMessage, merge_message_runs

def prepare_messages(
    messages: Sequence[AnyMessage], system_prompt: str
) -> list[AnyMessage]:
    """Merge message runs and add instructions before and after to stay on task."""
    sys = {
        "role": "system",
        "content": f"""{system_prompt}

<memory-system>Reflect on following interaction. Use the provided tools to \
 retain any necessary memories about the user. Use parallel tool calling to handle updates & insertions simultaneously.</memory-system>
""",
    }
    m = {
        "role": "user",
        "content": "## End of conversation\n\n"
        "<memory-system>Reflect on the interaction above."
        " What memories ought to be retained or updated?</memory-system>",
    }
    return list(merge_message_runs(messages=[sys] + list(messages) + [m]))

def split_model_and_provider(fully_specified_name: str) -> dict:
    """Initialize the configured chat model."""
    if "/" in fully_specified_name:
        provider, model = fully_specified_name.split("/", maxsplit=1)
    else:
        provider = None
        model = fully_specified_name
    return {"model": model, "provider": provider}

def get_pg_conn_str() -> str:
    import os
    username = os.getenv("PSQL_USERNAME")
    password = os.getenv("PSQL_PASSWORD")
    host = os.getenv("PSQL_HOST")
    port = os.getenv("PSQL_PORT")
    database = os.getenv("PSQL_DATABASE")
    sslmode = os.getenv("PSQL_SSLMODE", "disable")
    if not all([username, password, host, port, database]):
        raise ValueError("Missing required PostgreSQL env variables.")
    return f"postgresql://{username}:{password}@{host}:{port}/{database}?sslmode={sslmode}"

def get_azure_openai_model():
    import os
    from langchain_openai import AzureChatOpenAI
    from pydantic import SecretStr
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    if not api_key:
        raise ValueError("Missing required AZURE_OPENAI_API_KEY environment variable.")
    return AzureChatOpenAI(
        api_key=SecretStr(api_key),
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        api_version="2024-02-15-preview",
        model="gpt-4o",
        temperature=0.7,
    )